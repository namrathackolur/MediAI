import { type NextRequest, NextResponse } from "next/server"
import {
  extractDrugsWithGranite,
  findDrugInteractionsWithGranite,
  generateDosageRecommendations,
  generateAlternatives,
  type DrugInfo,
} from "@/lib/prescription-analyzer"

interface DrugExtraction {
  name: string
  dosage: string
  frequency: string
  confidence: number
}

interface PrescriptionAnalysis {
  extractedDrugs: DrugExtraction[]
  rawText: string
  patientAge?: number
  patientWeight?: number
}

// Common drug patterns and their variations
const DRUG_PATTERNS = {
  lisinopril: ["lisinopril", "prinivil", "zestril"],
  metformin: ["metformin", "glucophage", "fortamet"],
  atorvastatin: ["atorvastatin", "lipitor"],
  amlodipine: ["amlodipine", "norvasc"],
  omeprazole: ["omeprazole", "prilosec"],
  simvastatin: ["simvastatin", "zocor"],
  losartan: ["losartan", "cozaar"],
  hydrochlorothiazide: ["hydrochlorothiazide", "hctz", "microzide"],
  gabapentin: ["gabapentin", "neurontin"],
  sertraline: ["sertraline", "zoloft"],
  levothyroxine: ["levothyroxine", "synthroid", "levoxyl"],
  ibuprofen: ["ibuprofen", "advil", "motrin"],
  acetaminophen: ["acetaminophen", "tylenol", "paracetamol"],
  aspirin: ["aspirin", "bayer", "ecotrin"],
  warfarin: ["warfarin", "coumadin"],
  furosemide: ["furosemide", "lasix"],
  prednisone: ["prednisone", "deltasone"],
  albuterol: ["albuterol", "proventil", "ventolin"],
  insulin: ["insulin", "humulin", "novolog", "lantus"],
  clopidogrel: ["clopidogrel", "plavix"],
}

// Dosage patterns
const DOSAGE_REGEX = /(\d+(?:\.\d+)?)\s*(mg|g|ml|mcg|units?|iu)\b/gi
const FREQUENCY_PATTERNS = [
  { pattern: /once\s+(?:a\s+)?daily|1\s*x\s*daily|qd/gi, frequency: "Once daily" },
  { pattern: /twice\s+(?:a\s+)?daily|2\s*x\s*daily|bid/gi, frequency: "Twice daily" },
  { pattern: /three\s+times\s+(?:a\s+)?daily|3\s*x\s*daily|tid/gi, frequency: "Three times daily" },
  { pattern: /four\s+times\s+(?:a\s+)?daily|4\s*x\s*daily|qid/gi, frequency: "Four times daily" },
  { pattern: /every\s+(\d+)\s+hours?|q(\d+)h/gi, frequency: "Every $1 hours" },
  { pattern: /as\s+needed|prn/gi, frequency: "As needed" },
  { pattern: /at\s+bedtime|hs/gi, frequency: "At bedtime" },
  { pattern: /with\s+meals/gi, frequency: "With meals" },
]

function extractDrugsFromText(text: string): DrugExtraction[] {
  const extractedDrugs: DrugExtraction[] = []
  const lowerText = text.toLowerCase()

  // Split text into lines for better parsing
  const lines = text.split(/[\n\r]+/).filter((line) => line.trim())

  for (const [genericName, variations] of Object.entries(DRUG_PATTERNS)) {
    for (const variation of variations) {
      const drugRegex = new RegExp(`\\b${variation}\\b`, "gi")
      const matches = lowerText.match(drugRegex)

      if (matches) {
        // Find the line containing this drug
        const drugLine = lines.find((line) => line.toLowerCase().includes(variation.toLowerCase())) || text

        // Extract dosage
        const dosageMatches = drugLine.match(DOSAGE_REGEX)
        const dosage = dosageMatches ? dosageMatches[0] : "Not specified"

        // Extract frequency
        let frequency = "Not specified"
        for (const freqPattern of FREQUENCY_PATTERNS) {
          const freqMatch = drugLine.match(freqPattern.pattern)
          if (freqMatch) {
            frequency = freqPattern.frequency.replace(/\$(\d+)/g, (_, num) => freqMatch[Number.parseInt(num)] || num)
            break
          }
        }

        // Calculate confidence based on context
        let confidence = 0.7 // Base confidence
        if (dosageMatches) confidence += 0.15
        if (frequency !== "Not specified") confidence += 0.15
        if (variation === genericName) confidence += 0.05 // Higher for generic names

        confidence = Math.min(confidence, 0.99)

        // Check if we already extracted this drug
        const existingDrug = extractedDrugs.find((drug) => drug.name.toLowerCase() === genericName.toLowerCase())

        if (!existingDrug) {
          extractedDrugs.push({
            name: genericName.charAt(0).toUpperCase() + genericName.slice(1),
            dosage,
            frequency,
            confidence: Math.round(confidence * 100) / 100,
          })
        }

        break // Found this drug, move to next
      }
    }
  }

  return extractedDrugs.sort((a, b) => b.confidence - a.confidence)
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { prescriptionText, patientAge, patientWeight } = body

    if (!prescriptionText || typeof prescriptionText !== "string") {
      return NextResponse.json({ error: "Prescription text is required" }, { status: 400 })
    }

    let extractedDrugs: DrugInfo[]

    try {
      // Try IBM Granite model first
      extractedDrugs = await extractDrugsWithGranite(prescriptionText)
      console.log("Successfully used IBM Granite model for drug extraction")
    } catch (error) {
      console.warn("Granite model failed, using fallback extraction:", error)
      // Fallback to pattern-based extraction
      const fallbackDrugs = extractDrugsFromText(prescriptionText)
      extractedDrugs = fallbackDrugs.map((drug) => ({
        ...drug,
        genericName: drug.name,
        brandNames: [],
        therapeuticClass: "Unknown",
      }))
    }

    const drugNames = extractedDrugs.map((drug) => drug.name)

    // Get drug interactions using Granite model
    const interactions = await findDrugInteractionsWithGranite(drugNames)

    // Generate dosage recommendations
    const dosageRecommendations = generateDosageRecommendations(
      extractedDrugs,
      patientAge ? Number.parseInt(patientAge.toString()) : undefined,
      patientWeight ? Number.parseFloat(patientWeight.toString()) : undefined,
    )

    // Generate alternative medications
    const alternatives = generateAlternatives(extractedDrugs)

    const analysis = {
      extractedDrugs: extractedDrugs.map((drug) => ({
        name: drug.name,
        dosage: drug.dosage,
        frequency: drug.frequency,
        confidence: drug.confidence,
        genericName: drug.genericName,
        brandNames: drug.brandNames,
        therapeuticClass: drug.therapeuticClass,
      })),
      interactions,
      dosageRecommendations,
      alternatives,
      rawText: prescriptionText,
      patientAge: patientAge ? Number.parseInt(patientAge.toString()) : undefined,
      patientWeight: patientWeight ? Number.parseFloat(patientWeight.toString()) : undefined,
      analysisMethod:
        extractedDrugs.length > 0 && extractedDrugs[0].confidence > 0.9 ? "IBM Granite AI" : "Pattern Matching",
    }

    return NextResponse.json({
      success: true,
      analysis,
    })
  } catch (error) {
    console.error("Error analyzing prescription:", error)
    return NextResponse.json({ error: "Failed to analyze prescription" }, { status: 500 })
  }
}
