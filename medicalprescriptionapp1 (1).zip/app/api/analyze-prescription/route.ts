import { type NextRequest, NextResponse } from "next/server"

interface DrugInfo {
  name: string
  dosage: string
  frequency: string
  confidence: number
  genericName: string
  brandNames: string[]
  therapeuticClass: string
}

interface DrugInteraction {
  drug1: string
  drug2: string
  severity: "high" | "moderate" | "low"
  description: string
  mechanism: string
  clinicalEffect: string
}

interface DosageRecommendation {
  drug: string
  recommendedDosage: string
  reason: string
  ageSpecific: boolean
  weightBased: boolean
  currentDosage?: string
}

interface AlternativeMedication {
  originalDrug: string
  alternative: string
  reason: string
  benefits: string[]
  considerations: string[]
  therapeuticEquivalence: number
}

interface AnalysisResult {
  success: boolean
  analysis: {
    extractedDrugs: DrugInfo[]
    interactions: DrugInteraction[]
    dosageRecommendations: DosageRecommendation[]
    alternatives: AlternativeMedication[]
    rawText: string
    patientAge?: number
    patientWeight?: number
    analysisMethod: string
  }
}

// Mock drug database for pattern matching
const DRUG_DATABASE = {
  lisinopril: {
    name: "Lisinopril",
    genericName: "Lisinopril",
    brandNames: ["Prinivil", "Zestril"],
    therapeuticClass: "ACE Inhibitor",
    commonDosages: ["5mg", "10mg", "20mg", "40mg"],
    commonFrequencies: ["once daily", "twice daily"],
  },
  metformin: {
    name: "Metformin",
    genericName: "Metformin",
    brandNames: ["Glucophage", "Fortamet", "Glumetza"],
    therapeuticClass: "Biguanide",
    commonDosages: ["500mg", "850mg", "1000mg"],
    commonFrequencies: ["once daily", "twice daily", "three times daily"],
  },
  atorvastatin: {
    name: "Atorvastatin",
    genericName: "Atorvastatin",
    brandNames: ["Lipitor"],
    therapeuticClass: "Statin",
    commonDosages: ["10mg", "20mg", "40mg", "80mg"],
    commonFrequencies: ["once daily", "at bedtime"],
  },
  aspirin: {
    name: "Aspirin",
    genericName: "Aspirin",
    brandNames: ["Bayer", "Bufferin", "Ecotrin"],
    therapeuticClass: "NSAID/Antiplatelet",
    commonDosages: ["81mg", "325mg"],
    commonFrequencies: ["once daily", "twice daily"],
  },
  warfarin: {
    name: "Warfarin",
    genericName: "Warfarin",
    brandNames: ["Coumadin", "Jantoven"],
    therapeuticClass: "Anticoagulant",
    commonDosages: ["1mg", "2mg", "2.5mg", "3mg", "4mg", "5mg", "6mg", "7.5mg", "10mg"],
    commonFrequencies: ["once daily"],
  },
  omeprazole: {
    name: "Omeprazole",
    genericName: "Omeprazole",
    brandNames: ["Prilosec", "Zegerid"],
    therapeuticClass: "Proton Pump Inhibitor",
    commonDosages: ["10mg", "20mg", "40mg"],
    commonFrequencies: ["once daily", "twice daily"],
  },
}

// Mock interaction database
const INTERACTION_DATABASE = [
  {
    drug1: "Warfarin",
    drug2: "Aspirin",
    severity: "high" as const,
    description: "Increased risk of bleeding when warfarin is combined with aspirin",
    mechanism: "Both drugs affect blood clotting mechanisms",
    clinicalEffect: "Significantly increased bleeding risk, especially gastrointestinal bleeding",
  },
  {
    drug1: "Lisinopril",
    drug2: "Aspirin",
    severity: "moderate" as const,
    description: "Aspirin may reduce the antihypertensive effect of ACE inhibitors",
    mechanism: "Aspirin inhibits prostaglandin synthesis which may counteract ACE inhibitor effects",
    clinicalEffect: "Potential reduction in blood pressure lowering effect",
  },
  {
    drug1: "Atorvastatin",
    drug2: "Warfarin",
    severity: "moderate" as const,
    description: "Atorvastatin may enhance the anticoagulant effect of warfarin",
    mechanism: "Statins may inhibit warfarin metabolism",
    clinicalEffect: "Increased INR and bleeding risk - monitor closely",
  },
]

function extractDrugsFromText(text: string): DrugInfo[] {
  const extractedDrugs: DrugInfo[] = []
  const lines = text.split("\n").filter((line) => line.trim())

  for (const line of lines) {
    const lowerLine = line.toLowerCase()

    // Check each drug in our database
    for (const [key, drugInfo] of Object.entries(DRUG_DATABASE)) {
      if (lowerLine.includes(key)) {
        // Extract dosage using regex
        const dosageMatch = line.match(/(\d+(?:\.\d+)?)\s*mg/i)
        const dosage = dosageMatch ? `${dosageMatch[1]}mg` : "Dosage not specified"

        // Extract frequency
        let frequency = "Frequency not specified"
        if (lowerLine.includes("once daily") || lowerLine.includes("daily")) {
          frequency = "Once daily"
        } else if (lowerLine.includes("twice daily") || lowerLine.includes("bid")) {
          frequency = "Twice daily"
        } else if (lowerLine.includes("three times daily") || lowerLine.includes("tid")) {
          frequency = "Three times daily"
        } else if (lowerLine.includes("at bedtime") || lowerLine.includes("bedtime")) {
          frequency = "At bedtime"
        } else if (lowerLine.includes("with meals")) {
          frequency = "With meals"
        }

        extractedDrugs.push({
          name: drugInfo.name,
          dosage,
          frequency,
          confidence: 0.95,
          genericName: drugInfo.genericName,
          brandNames: drugInfo.brandNames,
          therapeuticClass: drugInfo.therapeuticClass,
        })
        break
      }
    }
  }

  return extractedDrugs
}

function findDrugInteractions(drugs: DrugInfo[]): DrugInteraction[] {
  const interactions: DrugInteraction[] = []
  const drugNames = drugs.map((drug) => drug.name)

  for (const interaction of INTERACTION_DATABASE) {
    if (drugNames.includes(interaction.drug1) && drugNames.includes(interaction.drug2)) {
      interactions.push(interaction)
    }
  }

  return interactions
}

function generateDosageRecommendations(
  drugs: DrugInfo[],
  patientAge?: number,
  patientWeight?: number,
): DosageRecommendation[] {
  const recommendations: DosageRecommendation[] = []

  for (const drug of drugs) {
    // Age-based recommendations
    if (patientAge && patientAge >= 65) {
      if (drug.name === "Lisinopril") {
        const currentDosageNum = Number.parseInt(drug.dosage.replace("mg", ""))
        if (currentDosageNum > 10) {
          recommendations.push({
            drug: drug.name,
            currentDosage: drug.dosage,
            recommendedDosage: "5-10mg once daily",
            reason: "Lower starting dose recommended for elderly patients",
            ageSpecific: true,
            weightBased: false,
          })
        }
      }
    }

    // Weight-based recommendations
    if (patientWeight && drug.name === "Metformin") {
      const currentDosageNum = Number.parseInt(drug.dosage.replace("mg", ""))
      if (patientWeight < 60 && currentDosageNum > 500) {
        recommendations.push({
          drug: drug.name,
          currentDosage: drug.dosage,
          recommendedDosage: "500mg twice daily",
          reason: "Lower dose recommended for patients with lower body weight",
          ageSpecific: false,
          weightBased: true,
        })
      }
    }
  }

  return recommendations
}

function generateAlternatives(drugs: DrugInfo[]): AlternativeMedication[] {
  const alternatives: AlternativeMedication[] = []

  for (const drug of drugs) {
    if (drug.name === "Atorvastatin") {
      alternatives.push({
        originalDrug: drug.name,
        alternative: "Rosuvastatin",
        reason: "More potent statin with potentially fewer drug interactions",
        benefits: ["Higher potency", "Less drug interactions", "Better LDL reduction"],
        considerations: ["May be more expensive", "Requires dose adjustment"],
        therapeuticEquivalence: 0.85,
      })
    }

    if (drug.name === "Lisinopril") {
      alternatives.push({
        originalDrug: drug.name,
        alternative: "Losartan",
        reason: "ARB alternative with similar efficacy and potentially fewer side effects",
        benefits: ["Less cough side effect", "Similar cardiovascular protection", "Better tolerability"],
        considerations: ["Different mechanism of action", "May require dose titration"],
        therapeuticEquivalence: 0.9,
      })
    }
  }

  return alternatives
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { prescriptionText, patientAge, patientWeight, patientHeight } = body

    if (!prescriptionText || typeof prescriptionText !== "string") {
      return NextResponse.json({ success: false, error: "Prescription text is required" }, { status: 400 })
    }

    // Simulate AI processing delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Extract drugs from prescription text
    const extractedDrugs = extractDrugsFromText(prescriptionText)

    if (extractedDrugs.length === 0) {
      return NextResponse.json(
        {
          success: false,
          error: "No recognizable medications found in the prescription text",
        },
        { status: 400 },
      )
    }

    // Find drug interactions
    const interactions = findDrugInteractions(extractedDrugs)

    // Generate dosage recommendations
    const dosageRecommendations = generateDosageRecommendations(extractedDrugs, patientAge, patientWeight)

    // Generate alternative medications
    const alternatives = generateAlternatives(extractedDrugs)

    const result: AnalysisResult = {
      success: true,
      analysis: {
        extractedDrugs,
        interactions,
        dosageRecommendations,
        alternatives,
        rawText: prescriptionText,
        patientAge,
        patientWeight,
        analysisMethod: "AI Pattern Recognition",
      },
    }

    return NextResponse.json(result)
  } catch (error) {
    console.error("Prescription analysis error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Internal server error during prescription analysis",
      },
      { status: 500 },
    )
  }
}
