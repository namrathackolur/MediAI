import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { email, name } = await request.json()

    if (!email || !name) {
      return NextResponse.json({ success: false, error: "Email and name are required" }, { status: 400 })
    }

    // Simulate email sending delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    // In a real application, you would integrate with an email service like:
    // - Resend
    // - SendGrid
    // - AWS SES
    // - Nodemailer with SMTP

    console.log(`Sending welcome email to ${email} for ${name}`)

    // Mock email content
    const emailContent = {
      to: email,
      subject: "Welcome to DoctorAI - Your AI-Powered Healthcare Platform",
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Welcome to DoctorAI</title>
        </head>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
          <div style="background: linear-gradient(135deg, #14b8a6, #06b6d4); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
            <h1 style="color: white; margin: 0; font-size: 28px;">Welcome to DoctorAI</h1>
            <p style="color: white; margin: 10px 0 0 0; font-size: 16px;">Modernize Healthcare with AI</p>
          </div>
          
          <div style="background: white; padding: 30px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 10px 10px;">
            <h2 style="color: #14b8a6; margin-top: 0;">Hello ${name}!</h2>
            
            <p>Thank you for joining DoctorAI, the leading AI-powered healthcare platform. We're excited to help you transform your healthcare delivery through our precise, state-of-the-art AI solutions.</p>
            
            <div style="background: #f0fdfa; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #14b8a6;">
              <h3 style="color: #14b8a6; margin-top: 0;">What you can do with DoctorAI:</h3>
              <ul style="margin: 0; padding-left: 20px;">
                <li>AI-powered prescription analysis with 99.2% accuracy</li>
                <li>Comprehensive drug interaction detection</li>
                <li>Personalized dosage recommendations</li>
                <li>Find nearby hospitals and medical centers</li>
                <li>24/7 support from medical professionals</li>
              </ul>
            </div>
            
            <div style="text-align: center; margin: 30px 0;">
              <a href="#" style="background: #14b8a6; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block;">Get Started Now</a>
            </div>
            
            <div style="background: #fef3c7; padding: 15px; border-radius: 8px; margin: 20px 0;">
              <h4 style="color: #92400e; margin-top: 0;">🔒 Security & Privacy</h4>
              <p style="margin: 0; color: #92400e; font-size: 14px;">Your data is protected with enterprise-grade security, HIPAA compliance, and end-to-end encryption. We never store patient information permanently.</p>
            </div>
            
            <div style="border-top: 1px solid #e5e7eb; padding-top: 20px; margin-top: 30px;">
              <h4 style="color: #374151;">Need Help?</h4>
              <p style="margin: 10px 0;">Our support team is available 24/7 to assist you:</p>
              <ul style="margin: 0; padding-left: 20px; color: #6b7280;">
                <li>Email: support@doctorai.com</li>
                <li>Phone: +1 (555) 123-4567</li>
                <li>Live Chat: Available in your dashboard</li>
              </ul>
            </div>
            
            <div style="text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px solid #e5e7eb; color: #6b7280; font-size: 14px;">
              <p>Best regards,<br>The DoctorAI Team</p>
              <p style="margin-top: 20px;">
                <a href="#" style="color: #14b8a6; text-decoration: none; margin: 0 10px;">Privacy Policy</a> |
                <a href="#" style="color: #14b8a6; text-decoration: none; margin: 0 10px;">Terms of Service</a> |
                <a href="#" style="color: #14b8a6; text-decoration: none; margin: 0 10px;">Unsubscribe</a>
              </p>
            </div>
          </div>
        </body>
        </html>
      `,
      text: `
        Welcome to DoctorAI, ${name}!
        
        Thank you for joining our AI-powered healthcare platform. We're excited to help you modernize healthcare delivery through our precise, state-of-the-art AI solutions.
        
        What you can do with DoctorAI:
        • AI-powered prescription analysis with 99.2% accuracy
        • Comprehensive drug interaction detection
        • Personalized dosage recommendations
        • Find nearby hospitals and medical centers
        • 24/7 support from medical professionals
        
        Your data is protected with enterprise-grade security, HIPAA compliance, and end-to-end encryption.
        
        Need help? Contact us:
        • Email: support@doctorai.com
        • Phone: +1 (555) 123-4567
        • Live Chat: Available in your dashboard
        
        Best regards,
        The DoctorAI Team
      `,
    }

    // Log the email content for development
    console.log("Email would be sent with content:", emailContent)

    // Simulate successful email sending
    return NextResponse.json({
      success: true,
      message: "Welcome email sent successfully",
      emailSent: true,
    })
  } catch (error) {
    console.error("Email sending error:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to send welcome email",
      },
      { status: 500 },
    )
  }
}
