import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "DoctorAI - Modernize Healthcare with Advanced AI",
  description:
    "Transform healthcare delivery through precise, state-of-the-art AI solutions. Advanced prescription analysis, drug interaction detection, and healthcare network integration.",
  keywords:
    "healthcare AI, prescription analysis, drug interactions, medical AI, healthcare technology, HIPAA compliant, doctor AI, medical analysis",
  authors: [{ name: "DoctorAI Team" }],
  viewport: "width=device-width, initial-scale=1",
  openGraph: {
    title: "DoctorAI - Modernize Healthcare with Advanced AI",
    description: "Transform healthcare delivery through precise, state-of-the-art AI solutions",
    type: "website",
    url: "https://doctorai.com",
  },
  twitter: {
    card: "summary_large_image",
    title: "DoctorAI - Modernize Healthcare with Advanced AI",
    description: "Transform healthcare delivery through precise, state-of-the-art AI solutions",
  },
    generator: 'v0.app'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>{children}</body>
    </html>
  )
}
