"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  CheckCircle,
  Pill,
  AlertTriangle,
  UserCheck,
  Info,
  Mail,
  Brain,
  HospitalIcon,
  MapPin,
  Phone,
  Clock,
  Star,
  HelpCircle,
  LogOut,
} from "lucide-react"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"

interface DrugInfo {
  name: string
  dosage: string
  frequency: string
  confidence: number
  genericName: string
  brandNames: string[]
  therapeuticClass: string
}

interface DrugInteraction {
  drug1: string
  drug2: string
  severity: "high" | "moderate" | "low"
  description: string
  mechanism: string
  clinicalEffect: string
}

interface DosageRecommendation {
  drug: string
  recommendedDosage: string
  reason: string
  ageSpecific: boolean
  weightBased: boolean
  currentDosage?: string
}

interface AlternativeMedication {
  originalDrug: string
  alternative: string
  reason: string
  benefits: string[]
  considerations: string[]
  therapeuticEquivalence: number
}

interface AnalysisResult {
  success: boolean
  analysis: {
    extractedDrugs: DrugInfo[]
    interactions: DrugInteraction[]
    dosageRecommendations: DosageRecommendation[]
    alternatives: AlternativeMedication[]
    rawText: string
    patientAge?: number
    patientWeight?: number
    analysisMethod: string
  }
}

interface Hospital {
  id: number
  name: string
  address: string
  distance: string
  rating: number
  phone: string
  specialties: string[]
  emergencyServices: boolean
  coordinates: { lat: number; lng: number }
  type: "hospital" | "clinic" | "emergency"
}

interface Pharmacy {
  id: number
  name: string
  address: string
  distance: string
  rating: number
  phone: string
  services: string[]
  isOpen24Hours: boolean
  coordinates: { lat: number; lng: number }
  type: "chain" | "independent" | "hospital"
}

function LandingPage({ onGetStarted }: { onGetStarted: () => void }) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 via-cyan-50 to-blue-50 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0">
        <svg className="absolute inset-0 w-full h-full" viewBox="0 0 1200 800" preserveAspectRatio="xMidYMid slice">
          <defs>
            <linearGradient id="gradient1" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#14b8a6" stopOpacity="0.1" />
              <stop offset="50%" stopColor="#06b6d4" stopOpacity="0.05" />
              <stop offset="100%" stopColor="#3b82f6" stopOpacity="0.1" />
            </linearGradient>
          </defs>
          <path d="M0,200 Q300,100 600,200 T1200,150 L1200,0 L0,0 Z" fill="url(#gradient1)" />
          <path d="M0,400 Q400,300 800,400 T1200,350 L1200,200 L0,300 Z" fill="url(#gradient1)" opacity="0.5" />
          <path d="M0,600 Q500,500 1000,600 T1200,550 L1200,400 L0,500 Z" fill="url(#gradient1)" opacity="0.3" />
        </svg>
      </div>

      {/* Header */}
      <header className="relative z-10 px-6 py-4">
        <nav className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-teal-600 rounded-full flex items-center justify-center">
              <Brain className="h-7 w-7 text-white" />
            </div>
            <span className="text-xl font-bold text-gray-800">DoctorAI</span>
          </div>

          <div className="hidden md:flex items-center gap-8">
            <a href="#about" className="text-gray-600 hover:text-teal-600 transition-colors">
              About us
            </a>
            <a href="#contact" className="text-gray-600 hover:text-teal-600 transition-colors">
              Contact us
            </a>
            <Button onClick={onGetStarted} className="bg-teal-600 hover:bg-teal-700 text-white px-6 py-2 rounded-lg">
              Get Started
            </Button>
          </div>
        </nav>
      </header>

      {/* Main Content */}
      <main className="relative z-10 max-w-7xl mx-auto px-6 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center min-h-[600px]">
          {/* Left Content */}
          <div className="space-y-8">
            <div className="space-y-6">
              <h1 className="text-6xl font-bold text-gray-900 leading-tight">DOCTORAI</h1>
              <h2 className="text-4xl font-bold text-gray-800 leading-tight">
                MODERNIZE
                <br />
                HEALTHCARE
              </h2>
              <p className="text-xl text-gray-600 leading-relaxed max-w-lg">
                We are transforming healthcare delivery through our precise, state-of-the-art AI solutions.
              </p>
            </div>

            <Button
              onClick={onGetStarted}
              className="bg-teal-600 hover:bg-teal-700 text-white px-8 py-4 text-lg rounded-lg shadow-lg hover:shadow-xl transition-all duration-300"
            >
              Get Started
            </Button>
          </div>

          {/* Right Content - AI Brain Illustration */}
          <div className="relative flex items-center justify-center">
            <div className="relative">
              {/* Robotic Hand */}
              <div className="relative z-10">
                <svg width="400" height="300" viewBox="0 0 400 300" className="drop-shadow-2xl">
                  {/* Hand Palm */}
                  <ellipse cx="200" cy="220" rx="80" ry="40" fill="url(#handGradient)" />

                  {/* Fingers */}
                  <rect x="120" y="180" width="20" height="60" rx="10" fill="url(#fingerGradient)" />
                  <rect x="150" y="160" width="20" height="80" rx="10" fill="url(#fingerGradient)" />
                  <rect x="180" y="150" width="20" height="90" rx="10" fill="url(#fingerGradient)" />
                  <rect x="210" y="160" width="20" height="80" rx="10" fill="url(#fingerGradient)" />
                  <rect x="240" y="180" width="20" height="60" rx="10" fill="url(#fingerGradient)" />

                  {/* Thumb */}
                  <ellipse
                    cx="280"
                    cy="200"
                    rx="15"
                    ry="35"
                    fill="url(#fingerGradient)"
                    transform="rotate(30 280 200)"
                  />

                  {/* Joint Details */}
                  <circle cx="130" cy="200" r="3" fill="#94a3b8" />
                  <circle cx="160" cy="180" r="3" fill="#94a3b8" />
                  <circle cx="190" cy="170" r="3" fill="#94a3b8" />
                  <circle cx="220" cy="180" r="3" fill="#94a3b8" />
                  <circle cx="250" cy="200" r="3" fill="#94a3b8" />

                  <defs>
                    <linearGradient id="handGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#e2e8f0" />
                      <stop offset="100%" stopColor="#cbd5e1" />
                    </linearGradient>
                    <linearGradient id="fingerGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#f1f5f9" />
                      <stop offset="100%" stopColor="#e2e8f0" />
                    </linearGradient>
                  </defs>
                </svg>
              </div>

              {/* AI Brain */}
              <div className="absolute -top-20 left-1/2 transform -translate-x-1/2">
                <div className="relative">
                  <svg width="200" height="150" viewBox="0 0 200 150" className="animate-pulse">
                    {/* Brain Shape */}
                    <path
                      d="M50 75 Q50 25 100 25 Q150 25 150 75 Q150 125 100 125 Q50 125 50 75"
                      fill="url(#brainGradient)"
                      opacity="0.8"
                    />

                    {/* Neural Network Lines */}
                    <g stroke="url(#neuralGradient)" strokeWidth="1" fill="none" opacity="0.6">
                      <path d="M60 50 L140 50 M60 75 L140 75 M60 100 L140 100" />
                      <path d="M75 35 L75 115 M100 35 L100 115 M125 35 L125 115" />
                      <circle cx="75" cy="50" r="3" fill="#3b82f6" />
                      <circle cx="100" cy="50" r="3" fill="#06b6d4" />
                      <circle cx="125" cy="50" r="3" fill="#14b8a6" />
                      <circle cx="75" cy="75" r="3" fill="#06b6d4" />
                      <circle cx="100" cy="75" r="3" fill="#14b8a6" />
                      <circle cx="125" cy="75" r="3" fill="#3b82f6" />
                      <circle cx="75" cy="100" r="3" fill="#14b8a6" />
                      <circle cx="100" cy="100" r="3" fill="#3b82f6" />
                      <circle cx="125" cy="100" r="3" fill="#06b6d4" />
                    </g>

                    <defs>
                      <linearGradient id="brainGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.3" />
                        <stop offset="50%" stopColor="#06b6d4" stopOpacity="0.4" />
                        <stop offset="100%" stopColor="#14b8a6" stopOpacity="0.3" />
                      </linearGradient>
                      <linearGradient id="neuralGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#3b82f6" />
                        <stop offset="50%" stopColor="#06b6d4" />
                        <stop offset="100%" stopColor="#14b8a6" />
                      </linearGradient>
                    </defs>
                  </svg>

                  {/* Floating Particles */}
                  <div className="absolute inset-0">
                    <div className="absolute top-4 left-8 w-2 h-2 bg-blue-400 rounded-full animate-bounce delay-100"></div>
                    <div className="absolute top-12 right-6 w-1.5 h-1.5 bg-teal-400 rounded-full animate-bounce delay-300"></div>
                    <div className="absolute bottom-8 left-12 w-1 h-1 bg-cyan-400 rounded-full animate-bounce delay-500"></div>
                    <div className="absolute bottom-4 right-10 w-1.5 h-1.5 bg-blue-500 rounded-full animate-bounce delay-700"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Features Section */}
      <section className="relative z-10 max-w-7xl mx-auto px-6 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-teal-100 rounded-lg flex items-center justify-center mb-4">
                <Pill className="h-6 w-6 text-teal-600" />
              </div>
              <CardTitle>AI Prescription Analysis</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Advanced AI-powered prescription verification with drug interaction detection and dosage optimization.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                <Brain className="h-6 w-6 text-blue-600" />
              </div>
              <CardTitle>Smart Medical AI</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Powered by advanced machine learning models for accurate medical analysis and recommendations.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardHeader>
              <div className="w-12 h-12 bg-cyan-100 rounded-lg flex items-center justify-center mb-4">
                <HospitalIcon className="h-6 w-6 text-cyan-600" />
              </div>
              <CardTitle>Healthcare Network</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Find nearby hospitals, clinics, and pharmacies with real-time availability and directions.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  )
}

function LoginForm({ onLogin }: { onLogin: (username: string) => void }) {
  const [isLogin, setIsLogin] = useState(true)
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [fullName, setFullName] = useState("")
  const [medicalId, setMedicalId] = useState("")
  const [specialization, setSpecialization] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")
  const [emailSent, setEmailSent] = useState(false)

  const sendWelcomeEmail = async (email: string, name: string) => {
    try {
      const response = await fetch("/api/send-welcome-email", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, name }),
      })

      const result = await response.json()
      if (result.success) {
        setEmailSent(true)
        console.log("Welcome email sent successfully")
      }
    } catch (error) {
      console.error("Failed to send welcome email:", error)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")
    setSuccess("")
    setEmailSent(false)

    if (isLogin) {
      setTimeout(async () => {
        if (username.trim() && password.trim()) {
          let displayName = ""
          let userEmail = ""

          if (username === "doctor" && password === "medical123") {
            displayName = "Dr. Demo User"
            userEmail = "demo@doctorai.com"
          } else if (username.includes("@") && password.length >= 6) {
            const emailName = username.split("@")[0]
            displayName = `Dr. ${emailName.charAt(0).toUpperCase() + emailName.slice(1)}`
            userEmail = username
          } else if (username.length >= 3 && password.length >= 6) {
            displayName = `Dr. ${username.charAt(0).toUpperCase() + username.slice(1)}`
            userEmail = `${username}@doctorai.com`
          } else {
            setError("Invalid credentials. Please check your username/email and password.")
            setIsLoading(false)
            return
          }

          if (userEmail && username.includes("@")) {
            await sendWelcomeEmail(userEmail, displayName)
          }

          onLogin(displayName)
        } else {
          setError("Please enter both username/email and password")
        }
        setIsLoading(false)
      }, 1000)
    } else {
      setTimeout(async () => {
        if (!username.trim() || !password.trim() || !fullName.trim() || !medicalId.trim()) {
          setError("Please fill in all required fields")
          setIsLoading(false)
          return
        }

        if (password !== confirmPassword) {
          setError("Passwords do not match")
          setIsLoading(false)
          return
        }

        if (password.length < 6) {
          setError("Password must be at least 6 characters long")
          setIsLoading(false)
          return
        }

        const userEmail = username.includes("@") ? username : `${username}@doctorai.com`
        await sendWelcomeEmail(userEmail, fullName)

        setSuccess("Account created successfully! Welcome email sent. You can now sign in with your credentials.")
        setIsLogin(true)
        setUsername("")
        setPassword("")
        setConfirmPassword("")
        setFullName("")
        setMedicalId("")
        setSpecialization("")
        setIsLoading(false)
      }, 1500)
    }
  }

  const toggleMode = () => {
    setIsLogin(!isLogin)
    setError("")
    setSuccess("")
    setEmailSent(false)
    setUsername("")
    setPassword("")
    setConfirmPassword("")
    setFullName("")
    setMedicalId("")
    setSpecialization("")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 via-cyan-50 to-blue-50 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0">
        <svg className="absolute inset-0 w-full h-full" viewBox="0 0 1200 800" preserveAspectRatio="xMidYMid slice">
          <defs>
            <linearGradient id="bgGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#14b8a6" stopOpacity="0.1" />
              <stop offset="50%" stopColor="#06b6d4" stopOpacity="0.05" />
              <stop offset="100%" stopColor="#3b82f6" stopOpacity="0.1" />
            </linearGradient>
          </defs>
          <path d="M0,200 Q300,100 600,200 T1200,150 L1200,0 L0,0 Z" fill="url(#bgGradient)" />
          <path d="M0,400 Q400,300 800,400 T1200,350 L1200,200 L0,300 Z" fill="url(#bgGradient)" opacity="0.5" />
        </svg>
      </div>

      <div className="relative z-10 min-h-screen flex items-center justify-center p-6">
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <div className="flex items-center justify-center gap-3 mb-6">
              <div className="w-16 h-16 bg-teal-600 rounded-full flex items-center justify-center">
                <Brain className="h-8 w-8 text-white" />
              </div>
            </div>
            <h1 className="text-3xl font-bold text-gray-800 mb-2">DoctorAI</h1>
            <p className="text-gray-600">AI-Powered Healthcare Solutions</p>
          </div>

          <Card className="shadow-xl bg-white/95 backdrop-blur-sm border-0">
            <CardHeader className="text-center pb-4">
              <CardTitle className="flex items-center justify-center gap-2 text-xl">
                <UserCheck className="h-5 w-5 text-teal-600" />
                {isLogin ? "Welcome Back" : "Create Account"}
              </CardTitle>
              <CardDescription>
                {isLogin ? "Sign in to access your medical dashboard" : "Join our healthcare professional network"}
              </CardDescription>
            </CardHeader>

            <CardContent className="space-y-6">
              <form onSubmit={handleSubmit} className="space-y-4">
                {!isLogin && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="fullName">Full Name *</Label>
                      <Input
                        id="fullName"
                        type="text"
                        placeholder="Dr. John Smith"
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        disabled={isLoading}
                        className="h-11"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="medicalId">Medical License ID *</Label>
                      <Input
                        id="medicalId"
                        type="text"
                        placeholder="Enter your medical license number"
                        value={medicalId}
                        onChange={(e) => setMedicalId(e.target.value)}
                        disabled={isLoading}
                        className="h-11"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="specialization">Specialization (Optional)</Label>
                      <Input
                        id="specialization"
                        type="text"
                        placeholder="e.g., Internal Medicine"
                        value={specialization}
                        onChange={(e) => setSpecialization(e.target.value)}
                        disabled={isLoading}
                        className="h-11"
                      />
                    </div>
                  </>
                )}

                <div className="space-y-2">
                  <Label htmlFor="username">
                    {isLogin ? "Email or Username" : "Email Address"} {!isLogin && "*"}
                  </Label>
                  <Input
                    id="username"
                    type="text"
                    placeholder={isLogin ? "doctor@hospital.com" : "doctor@hospital.com"}
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    disabled={isLoading}
                    className="h-11"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password">Password {!isLogin && "*"}</Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder={isLogin ? "Enter password" : "Create password (min 6 chars)"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    disabled={isLoading}
                    className="h-11"
                  />
                </div>

                {!isLogin && (
                  <div className="space-y-2">
                    <Label htmlFor="confirmPassword">Confirm Password *</Label>
                    <Input
                      id="confirmPassword"
                      type="password"
                      placeholder="Confirm your password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      disabled={isLoading}
                      className="h-11"
                    />
                  </div>
                )}

                {success && (
                  <Alert className="border-green-200 bg-green-50">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <AlertDescription className="text-green-800">{success}</AlertDescription>
                  </Alert>
                )}

                {emailSent && (
                  <Alert className="border-blue-200 bg-blue-50">
                    <Mail className="h-4 w-4 text-blue-600" />
                    <AlertDescription className="text-blue-800">
                      Welcome email sent! Check your inbox for important information.
                    </AlertDescription>
                  </Alert>
                )}

                {error && (
                  <Alert variant="destructive">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                <Button
                  type="submit"
                  className="w-full h-12 text-lg font-semibold bg-teal-600 hover:bg-teal-700"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <>
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-3" />
                      {isLogin ? "Signing In..." : "Creating Account..."}
                    </>
                  ) : (
                    <>
                      <UserCheck className="h-5 w-5 mr-3" />
                      {isLogin ? "Sign In" : "Create Account"}
                    </>
                  )}
                </Button>
              </form>

              <div className="text-center">
                <Button
                  variant="link"
                  onClick={toggleMode}
                  disabled={isLoading}
                  className="text-teal-600 hover:text-teal-700"
                >
                  {isLogin ? "New here? Create an account" : "Already have an account? Sign in"}
                </Button>
              </div>

              {isLogin && (
                <div className="p-4 bg-gray-50 rounded-lg text-sm">
                  <p className="font-medium mb-2 text-gray-700">Quick Access:</p>
                  <div className="space-y-1 text-gray-600">
                    <p>• Email + password (6+ chars)</p>
                    <p>
                      • Demo: <code className="bg-white px-1 rounded">doctor</code> /{" "}
                      <code className="bg-white px-1 rounded">medical123</code>
                    </p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

function DashboardApp({ username, onLogout }: { username: string; onLogout: () => void }) {
  const [currentSection, setCurrentSection] = useState("dashboard")
  const [prescriptionText, setPrescriptionText] = useState("")
  const [patientAge, setPatientAge] = useState("")
  const [patientWeight, setPatientWeight] = useState("")
  const [patientHeight, setPatientHeight] = useState("")
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [showProfileDropdown, setShowProfileDropdown] = useState(false)

  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null)
  const [nearbyHospitals, setNearbyHospitals] = useState<Hospital[]>([])
  const [isLoadingLocation, setIsLoadingLocation] = useState(false)
  const [locationError, setLocationError] = useState<string | null>(null)

  const [isScanning, setIsScanning] = useState(false)
  const [scannedText, setScannedText] = useState("")
  const [nearbyPharmacies, setNearbyPharmacies] = useState<Pharmacy[]>([])
  const [scanError, setScanError] = useState<string | null>(null)

  const navigationItems = [
    { id: "dashboard", label: "Dashboard", icon: "🏥" },
    { id: "prescription", label: "AI Prescription Analysis", icon: "💊" },
    { id: "scan", label: "Scan Medical Report", icon: "📄" },
    { id: "results", label: "Analysis Results", icon: "📊" },
    { id: "hospitals", label: "Nearby Hospitals", icon: "🏥" },
    { id: "pharmacies", label: "Nearby Pharmacies", icon: "💊" },
    { id: "about", label: "About", icon: "ℹ️" },
    { id: "faq", label: "FAQ", icon: "❓" },
  ]

  const handleAnalyzePrescription = async () => {
    if (!prescriptionText.trim()) {
      setError("Please enter prescription text")
      return
    }

    setIsAnalyzing(true)
    setError(null)
    setAnalysisResult(null)

    try {
      const requestBody = {
        prescriptionText: prescriptionText.trim(),
        patientAge: patientAge ? Number.parseInt(patientAge) : undefined,
        patientWeight: patientWeight ? Number.parseFloat(patientWeight) : undefined,
        patientHeight: patientHeight ? Number.parseFloat(patientHeight) : undefined,
      }

      const response = await fetch("/api/analyze-prescription", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        body: JSON.stringify(requestBody),
      })

      const contentType = response.headers.get("content-type")
      if (!contentType || !contentType.includes("application/json")) {
        throw new Error("Server returned non-JSON response")
      }

      const result = await response.json()

      if (!response.ok) {
        throw new Error(result.error || `HTTP ${response.status}`)
      }

      if (result.success && result.analysis) {
        setAnalysisResult(result)
        setCurrentSection("results")
      } else {
        throw new Error(result.error || "Analysis failed")
      }
    } catch (err) {
      console.error("Prescription analysis error:", err)
      let errorMessage = "Failed to analyze prescription. "
      if (err instanceof Error) {
        errorMessage += err.message
      }
      setError(errorMessage)
    } finally {
      setIsAnalyzing(false)
    }
  }

  const findNearbyHospitals = () => {
    setIsLoadingLocation(true)
    setLocationError(null)

    if (!navigator.geolocation) {
      setLocationError("Geolocation is not supported by this browser")
      setIsLoadingLocation(false)
      return
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const location = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        }
        setUserLocation(location)

        // Mock nearby hospitals data
        const mockHospitals: Hospital[] = [
          {
            id: 1,
            name: "City General Hospital",
            address: `${Math.floor(Math.random() * 9999)} Medical Center Dr`,
            distance: `${(Math.random() * 2 + 0.1).toFixed(1)} miles`,
            rating: 4.5 + Math.random() * 0.5,
            phone: "(555) 123-4567",
            specialties: ["Emergency Medicine", "Cardiology", "Neurology", "Oncology"],
            emergencyServices: true,
            coordinates: {
              lat: location.lat + (Math.random() - 0.5) * 0.01,
              lng: location.lng + (Math.random() - 0.5) * 0.01,
            },
            type: "hospital",
          },
          {
            id: 2,
            name: "St. Mary's Medical Center",
            address: `${Math.floor(Math.random() * 9999)} Healthcare Blvd`,
            distance: `${(Math.random() * 3 + 0.5).toFixed(1)} miles`,
            rating: 4.2 + Math.random() * 0.6,
            phone: "(555) 234-5678",
            specialties: ["Pediatrics", "Obstetrics", "Orthopedics", "Internal Medicine"],
            emergencyServices: true,
            coordinates: {
              lat: location.lat + (Math.random() - 0.5) * 0.015,
              lng: location.lng + (Math.random() - 0.5) * 0.015,
            },
            type: "hospital",
          },
          {
            id: 3,
            name: "Regional Emergency Center",
            address: `${Math.floor(Math.random() * 9999)} Emergency Way`,
            distance: `${(Math.random() * 1.5 + 0.2).toFixed(1)} miles`,
            rating: 4.0 + Math.random() * 0.8,
            phone: "(555) 345-6789",
            specialties: ["Emergency Medicine", "Trauma Care", "Critical Care"],
            emergencyServices: true,
            coordinates: {
              lat: location.lat + (Math.random() - 0.5) * 0.008,
              lng: location.lng + (Math.random() - 0.5) * 0.008,
            },
            type: "emergency",
          },
          {
            id: 4,
            name: "Family Health Clinic",
            address: `${Math.floor(Math.random() * 9999)} Wellness St`,
            distance: `${(Math.random() * 2.5 + 0.3).toFixed(1)} miles`,
            rating: 4.3 + Math.random() * 0.5,
            phone: "(555) 456-7890",
            specialties: ["Family Medicine", "Preventive Care", "Vaccinations"],
            emergencyServices: false,
            coordinates: {
              lat: location.lat + (Math.random() - 0.5) * 0.012,
              lng: location.lng + (Math.random() - 0.5) * 0.012,
            },
            type: "clinic",
          },
        ]

        setNearbyHospitals(mockHospitals)
        setIsLoadingLocation(false)
      },
      (error) => {
        let errorMessage = "Unable to retrieve location"
        switch (error.code) {
          case error.PERMISSION_DENIED:
            errorMessage = "Location access denied by user"
            break
          case error.POSITION_UNAVAILABLE:
            errorMessage = "Location information unavailable"
            break
          case error.TIMEOUT:
            errorMessage = "Location request timed out"
            break
        }
        setLocationError(errorMessage)
        setIsLoadingLocation(false)
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 60000,
      },
    )
  }

  const findNearbyPharmacies = () => {
    setIsLoadingLocation(true)
    setLocationError(null)

    if (!navigator.geolocation) {
      setLocationError("Geolocation is not supported by this browser")
      setIsLoadingLocation(false)
      return
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const location = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        }
        setUserLocation(location)

        // Mock nearby pharmacies data
        const mockPharmacies: Pharmacy[] = [
          {
            id: 1,
            name: "CVS Pharmacy",
            address: `${Math.floor(Math.random() * 9999)} Main Street`,
            distance: `${(Math.random() * 1.5 + 0.1).toFixed(1)} miles`,
            rating: 4.2 + Math.random() * 0.6,
            phone: "(555) 234-5678",
            services: ["Prescription Filling", "Vaccinations", "Health Screenings", "Photo Services"],
            isOpen24Hours: Math.random() > 0.7,
            coordinates: {
              lat: location.lat + (Math.random() - 0.5) * 0.008,
              lng: location.lng + (Math.random() - 0.5) * 0.008,
            },
            type: "chain",
          },
          {
            id: 2,
            name: "Walgreens",
            address: `${Math.floor(Math.random() * 9999)} Oak Avenue`,
            distance: `${(Math.random() * 2 + 0.2).toFixed(1)} miles`,
            rating: 4.0 + Math.random() * 0.7,
            phone: "(555) 345-6789",
            services: ["Prescription Filling", "Flu Shots", "Blood Pressure Checks", "Diabetes Care"],
            isOpen24Hours: Math.random() > 0.8,
            coordinates: {
              lat: location.lat + (Math.random() - 0.5) * 0.01,
              lng: location.lng + (Math.random() - 0.5) * 0.01,
            },
            type: "chain",
          },
          {
            id: 3,
            name: "Community Pharmacy",
            address: `${Math.floor(Math.random() * 9999)} Elm Street`,
            distance: `${(Math.random() * 1.2 + 0.3).toFixed(1)} miles`,
            rating: 4.5 + Math.random() * 0.4,
            phone: "(555) 456-7890",
            services: ["Prescription Filling", "Medication Counseling", "Compounding", "Delivery Service"],
            isOpen24Hours: false,
            coordinates: {
              lat: location.lat + (Math.random() - 0.5) * 0.006,
              lng: location.lng + (Math.random() - 0.5) * 0.006,
            },
            type: "independent",
          },
          {
            id: 4,
            name: "Rite Aid Pharmacy",
            address: `${Math.floor(Math.random() * 9999)} Pine Road`,
            distance: `${(Math.random() * 2.5 + 0.4).toFixed(1)} miles`,
            rating: 3.8 + Math.random() * 0.8,
            phone: "(555) 567-8901",
            services: ["Prescription Filling", "Immunizations", "Health Tests", "Wellness Products"],
            isOpen24Hours: Math.random() > 0.9,
            coordinates: {
              lat: location.lat + (Math.random() - 0.5) * 0.012,
              lng: location.lng + (Math.random() - 0.5) * 0.012,
            },
            type: "chain",
          },
        ]

        setNearbyPharmacies(mockPharmacies)
        setIsLoadingLocation(false)
      },
      (error) => {
        let errorMessage = "Unable to retrieve location"
        switch (error.code) {
          case error.PERMISSION_DENIED:
            errorMessage = "Location access denied by user"
            break
          case error.POSITION_UNAVAILABLE:
            errorMessage = "Location information unavailable"
            break
          case error.TIMEOUT:
            errorMessage = "Location request timed out"
            break
        }
        setLocationError(errorMessage)
        setIsLoadingLocation(false)
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 60000,
      },
    )
  }

  const handleDocumentScan = async (file: File) => {
    setIsScanning(true)
    setScanError(null)
    setScannedText("")

    try {
      // Simulate OCR processing
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Mock OCR result based on file name or random medical text
      const mockScannedTexts = [
        `MEDICAL PRESCRIPTION REPORT

Patient: John Doe
Date: ${new Date().toLocaleDateString()}
Doctor: Dr. Sarah Johnson, MD

CURRENT MEDICATIONS:
1. Lisinopril 10mg - Take once daily for blood pressure
2. Metformin 500mg - Take twice daily with meals for diabetes
3. Atorvastatin 20mg - Take once daily at bedtime for cholesterol

MEDICAL HISTORY:
- Hypertension (High Blood Pressure)
- Type 2 Diabetes Mellitus
- Hyperlipidemia (High Cholesterol)

VITAL SIGNS:
- Blood Pressure: 140/90 mmHg
- Heart Rate: 78 bpm
- Weight: 180 lbs
- Height: 5'10"

LABORATORY RESULTS:
- HbA1c: 7.2% (Target: <7%)
- LDL Cholesterol: 120 mg/dL (Target: <100)
- Creatinine: 1.1 mg/dL (Normal)

RECOMMENDATIONS:
- Continue current medications
- Monitor blood glucose daily
- Follow up in 3 months
- Lifestyle modifications: diet and exercise`,

        `PRESCRIPTION ANALYSIS REPORT

Patient Information:
Name: Jane Smith
Age: 65 years
Weight: 150 lbs

PRESCRIBED MEDICATIONS:
1. Warfarin 5mg daily - Blood thinner to prevent clots
2. Aspirin 81mg daily - Low-dose for heart protection
3. Omeprazole 20mg daily - Stomach acid reducer

IMPORTANT NOTES:
- Patient has history of atrial fibrillation
- Regular INR monitoring required for warfarin
- Potential drug interaction between warfarin and aspirin

ALLERGIES:
- Penicillin (rash)
- Sulfa drugs (hives)

INSTRUCTIONS:
- Take warfarin at the same time each day
- Avoid alcohol while on warfarin
- Report any unusual bleeding or bruising
- Regular blood tests required`,
      ]

      const randomText = mockScannedTexts[Math.floor(Math.random() * mockScannedTexts.length)]
      setScannedText(randomText)
      setPrescriptionText(randomText)
    } catch (error) {
      setScanError("Failed to scan document. Please try again or enter text manually.")
      console.error("Document scanning error:", error)
    } finally {
      setIsScanning(false)
    }
  }

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      if (file.type.startsWith("image/") || file.type === "application/pdf") {
        handleDocumentScan(file)
      } else {
        setScanError("Please upload an image (JPG, PNG) or PDF file")
      }
    }
  }

  const getDirections = (hospital: Hospital | Pharmacy) => {
    if (userLocation && hospital.coordinates) {
      const origin = `${userLocation.lat},${userLocation.lng}`
      const destination = `${hospital.coordinates.lat},${hospital.coordinates.lng}`
      const googleMapsUrl = `https://www.google.com/maps/dir/${origin}/${destination}`
      window.open(googleMapsUrl, "_blank")
    } else {
      const query = encodeURIComponent(`${hospital.name} ${hospital.address}`)
      const googleMapsUrl = `https://www.google.com/maps/search/${query}`
      window.open(googleMapsUrl, "_blank")
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 via-cyan-50 to-blue-50 relative flex">
      {/* Sidebar */}
      <div className="w-64 bg-white/90 backdrop-blur-sm shadow-lg border-r border-teal-100">
        <div className="p-6">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-10 h-10 bg-teal-600 rounded-full flex items-center justify-center">
              <Brain className="h-6 w-6 text-white" />
            </div>
            <div>
              <h2 className="font-bold text-lg text-teal-800">DoctorAI</h2>
              <p className="text-sm text-teal-600">AI Healthcare Platform</p>
            </div>
          </div>

          <nav className="space-y-2">
            {navigationItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setCurrentSection(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left transition-colors ${
                  currentSection === item.id
                    ? "bg-teal-100 text-teal-800 font-medium"
                    : "text-gray-600 hover:bg-teal-50 hover:text-teal-700"
                }`}
              >
                <span className="text-lg">{item.icon}</span>
                <span className="text-sm">{item.label}</span>
              </button>
            ))}
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 relative z-10">
        {/* Header */}
        <div className="bg-white/90 backdrop-blur-sm border-b border-teal-100 px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-teal-800">Welcome, {username}</h1>
              <p className="text-teal-600">AI-Powered Medical Analysis Platform</p>
            </div>

            <div className="relative">
              <button
                onClick={() => setShowProfileDropdown(!showProfileDropdown)}
                className="flex items-center gap-3 p-2 rounded-lg hover:bg-teal-50 transition-colors"
              >
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-teal-500 to-cyan-600 flex items-center justify-center text-white font-semibold">
                  {username.charAt(0)}
                </div>
                <div className="text-left">
                  <p className="font-medium text-sm">{username}</p>
                  <p className="text-xs text-gray-500">Healthcare Professional</p>
                </div>
              </button>

              {showProfileDropdown && (
                <>
                  {/* Backdrop - Fixed positioning to cover entire viewport */}
                  <div className="fixed inset-0 z-[9998] bg-black/10" onClick={() => setShowProfileDropdown(false)} />

                  <div className="fixed top-16 right-8 w-48 bg-white rounded-lg shadow-2xl border border-teal-100 z-[9999] overflow-hidden">
                    <div className="p-4 border-b border-teal-100 bg-gradient-to-r from-teal-50 to-cyan-50">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-teal-500 to-cyan-600 flex items-center justify-center text-white font-semibold">
                          {username.charAt(0)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className="font-semibold text-gray-900 truncate">{username}</h3>
                          <p className="text-xs text-gray-600 truncate">Healthcare Professional</p>
                        </div>
                      </div>
                    </div>

                    <div className="p-4">
                      <Button
                        variant="outline"
                        className="w-full justify-start text-red-600 hover:text-red-700 hover:bg-red-50 text-sm h-11 bg-white border-red-200 hover:border-red-300"
                        size="sm"
                        onClick={() => {
                          setShowProfileDropdown(false)
                          onLogout()
                        }}
                      >
                        <LogOut className="h-4 w-4 mr-2" />
                        Logout
                      </Button>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>

        <div className="container mx-auto px-8 py-8 max-w-6xl">
          {/* Dashboard Section */}
          {currentSection === "dashboard" && (
            <div className="space-y-6">
              <div className="bg-gradient-to-r from-teal-500 to-cyan-600 rounded-2xl p-8 text-white relative overflow-hidden">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <h2 className="text-3xl font-bold mb-2">AI-Powered Medical Analysis</h2>
                    <p className="text-teal-100 text-lg mb-4">
                      Advanced healthcare insights with artificial intelligence
                    </p>
                    <div className="flex gap-4 text-sm">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-white rounded-full"></div>
                        <span>24/7 AI Analysis</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-white rounded-full"></div>
                        <span>Medical Expertise</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-white rounded-full"></div>
                        <span>Secure & Private</span>
                      </div>
                    </div>
                  </div>
                  <div className="hidden md:block">
                    <img
                      src="/confident-doctor.png"
                      alt="Professional Doctor"
                      className="w-48 h-48 object-cover rounded-lg"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="bg-white/90 backdrop-blur-sm">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Brain className="h-5 w-5 text-teal-600" />
                      AI Analysis
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-teal-600">247</div>
                    <p className="text-sm text-gray-500">Prescriptions analyzed</p>
                  </CardContent>
                </Card>

                <Card className="bg-white/90 backdrop-blur-sm">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <AlertTriangle className="h-5 w-5 text-orange-600" />
                      Interactions Found
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-orange-600">23</div>
                    <p className="text-sm text-gray-500">Prevented issues</p>
                  </CardContent>
                </Card>

                <Card className="bg-white/90 backdrop-blur-sm">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <CheckCircle className="h-5 w-5 text-green-600" />
                      AI Accuracy
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-green-600">99.2%</div>
                    <p className="text-sm text-gray-500">Analysis precision</p>
                  </CardContent>
                </Card>
              </div>

              <Card className="bg-white/90 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <img src="/medical-stethoscope-icon.png" alt="Medical Icon" className="w-6 h-6" />
                    Quick Actions
                  </CardTitle>
                  <CardDescription>AI-powered healthcare tools</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <Button
                      variant="outline"
                      className="h-20 flex-col gap-2 bg-transparent hover:bg-teal-50"
                      onClick={() => setCurrentSection("scan")}
                    >
                      <span className="text-xl">📄</span>
                      <span className="text-sm">Scan Report</span>
                    </Button>
                    <Button
                      variant="outline"
                      className="h-20 flex-col gap-2 bg-transparent hover:bg-cyan-50"
                      onClick={() => setCurrentSection("pharmacies")}
                    >
                      <span className="text-xl">💊</span>
                      <span className="text-sm">Find Pharmacies</span>
                    </Button>
                    <Button
                      variant="outline"
                      className="h-20 flex-col gap-2 bg-transparent hover:bg-blue-50"
                      onClick={() => setCurrentSection("hospitals")}
                    >
                      <HospitalIcon className="h-6 w-6 text-blue-600" />
                      <span className="text-sm">Find Hospitals</span>
                    </Button>
                    <Button
                      variant="outline"
                      className="h-20 flex-col gap-2 bg-transparent hover:bg-indigo-50"
                      onClick={() => setCurrentSection("prescription")}
                    >
                      <Brain className="h-6 w-6 text-indigo-600" />
                      <span className="text-sm">AI Analysis</span>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Prescription Analysis Section */}
          {currentSection === "prescription" && (
            <div className="space-y-6">
              <Card className="bg-white/90 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Brain className="h-5 w-5 text-teal-600" />
                    AI-Powered Prescription Analysis
                  </CardTitle>
                  <CardDescription>
                    Advanced AI-powered prescription analysis with comprehensive drug interaction detection
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="bg-teal-50 p-4 rounded-lg border border-teal-200">
                    <div className="flex items-center gap-3 mb-2">
                      <Brain className="h-5 w-5 text-teal-600" />
                      <h3 className="font-semibold text-teal-800">Advanced AI Analysis</h3>
                    </div>
                    <p className="text-sm text-teal-700">
                      Our AI uses state-of-the-art machine learning models for accurate medical analysis, drug
                      interaction detection, and personalized recommendations.
                    </p>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold mb-4">Patient Information</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="age">Patient Age (years)</Label>
                        <Input
                          id="age"
                          type="number"
                          placeholder="e.g., 45"
                          value={patientAge}
                          onChange={(e) => setPatientAge(e.target.value)}
                          min="0"
                          max="120"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="weight">Weight (kg)</Label>
                        <Input
                          id="weight"
                          type="number"
                          placeholder="e.g., 70"
                          value={patientWeight}
                          onChange={(e) => setPatientWeight(e.target.value)}
                          min="0"
                          max="300"
                          step="0.1"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="height">Height (cm)</Label>
                        <Input
                          id="height"
                          type="number"
                          placeholder="e.g., 175"
                          value={patientHeight}
                          onChange={(e) => setPatientHeight(e.target.value)}
                          min="0"
                          max="250"
                        />
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold mb-4">Prescription Details</h3>
                    <div className="space-y-2">
                      <Label htmlFor="prescription">Prescription Text</Label>
                      <Textarea
                        id="prescription"
                        className="min-h-[150px] resize-none"
                        placeholder="Enter prescription text here... 

Example:
Lisinopril 10mg once daily
Metformin 500mg twice daily with meals
Atorvastatin 20mg once daily at bedtime"
                        value={prescriptionText}
                        onChange={(e) => setPrescriptionText(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-medium mb-3">Sample Prescriptions (Click to use):</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      <Button
                        variant="outline"
                        className="h-auto p-3 text-left justify-start bg-white hover:bg-teal-50"
                        onClick={() =>
                          setPrescriptionText(
                            "Lisinopril 10mg once daily\nMetformin 500mg twice daily with meals\nAspirin 81mg once daily",
                          )
                        }
                      >
                        <div>
                          <div className="font-medium">Diabetes + Hypertension</div>
                          <div className="text-sm text-gray-600">Lisinopril, Metformin, Aspirin</div>
                        </div>
                      </Button>
                      <Button
                        variant="outline"
                        className="h-auto p-3 text-left justify-start bg-white hover:bg-teal-50"
                        onClick={() =>
                          setPrescriptionText(
                            "Atorvastatin 20mg once daily at bedtime\nWarfarin 5mg once daily\nOmeprazole 20mg once daily before breakfast",
                          )
                        }
                      >
                        <div>
                          <div className="font-medium">Cardiovascular</div>
                          <div className="text-sm text-gray-600">Atorvastatin, Warfarin, Omeprazole</div>
                        </div>
                      </Button>
                    </div>
                  </div>

                  {error && (
                    <Alert variant="destructive">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription>{error}</AlertDescription>
                    </Alert>
                  )}

                  <Button
                    onClick={handleAnalyzePrescription}
                    disabled={isAnalyzing || !prescriptionText.trim()}
                    className="w-full h-12 text-lg bg-teal-600 hover:bg-teal-700"
                  >
                    {isAnalyzing ? (
                      <>
                        <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-3" />
                        AI Analyzing Prescription...
                      </>
                    ) : (
                      <>
                        <Brain className="h-5 w-5 mr-3" />
                        Analyze with AI
                      </>
                    )}
                  </Button>

                  <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                    <h4 className="font-medium text-blue-800 mb-2">AI Analysis Includes:</h4>
                    <ul className="text-sm text-blue-700 space-y-1">
                      <li>• Advanced drug identification and extraction</li>
                      <li>• Comprehensive drug-drug interaction analysis</li>
                      <li>• Personalized dosage recommendations</li>
                      <li>• Alternative medication suggestions</li>
                      <li>• Age and weight-based adjustments</li>
                      <li>• Safety warnings and contraindications</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Scan Medical Report Section */}
          {currentSection === "scan" && (
            <div className="space-y-6">
              <Card className="bg-white/90 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <span className="text-xl">📄</span>
                    Scan Medical Report
                  </CardTitle>
                  <CardDescription>
                    Upload and scan your medical reports, prescriptions, or lab results for AI analysis
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="text-xl">🔍</span>
                      <h3 className="font-semibold text-blue-800">Advanced OCR Technology</h3>
                    </div>
                    <p className="text-sm text-blue-700">
                      Our AI-powered Optical Character Recognition (OCR) can read and analyze medical documents,
                      prescriptions, lab reports, and handwritten notes with high accuracy.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold">Upload Document</h3>
                      <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-teal-400 transition-colors">
                        <input
                          type="file"
                          accept="image/*,.pdf"
                          onChange={handleFileUpload}
                          className="hidden"
                          id="file-upload"
                          disabled={isScanning}
                        />
                        <label htmlFor="file-upload" className="cursor-pointer flex flex-col items-center gap-4">
                          <div className="w-16 h-16 bg-teal-100 rounded-full flex items-center justify-center">
                            <span className="text-2xl">📁</span>
                          </div>
                          <div>
                            <p className="text-lg font-medium text-gray-700">
                              {isScanning ? "Scanning..." : "Click to upload"}
                            </p>
                            <p className="text-sm text-gray-500">Supports: JPG, PNG, PDF files</p>
                          </div>
                        </label>
                      </div>

                      {isScanning && (
                        <div className="flex items-center justify-center gap-3 p-4 bg-teal-50 rounded-lg">
                          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-teal-600"></div>
                          <span className="text-teal-800 font-medium">Scanning document with AI...</span>
                        </div>
                      )}

                      {scanError && (
                        <Alert variant="destructive">
                          <AlertTriangle className="h-4 w-4" />
                          <AlertDescription>{scanError}</AlertDescription>
                        </Alert>
                      )}
                    </div>

                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold">Supported Documents</h3>
                      <div className="space-y-3">
                        <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                          <span className="text-xl">📋</span>
                          <div>
                            <p className="font-medium">Prescriptions</p>
                            <p className="text-sm text-gray-600">Handwritten or printed prescriptions</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                          <span className="text-xl">🧪</span>
                          <div>
                            <p className="font-medium">Lab Reports</p>
                            <p className="text-sm text-gray-600">Blood tests, urine tests, imaging results</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                          <span className="text-xl">📄</span>
                          <div>
                            <p className="font-medium">Medical Records</p>
                            <p className="text-sm text-gray-600">Doctor notes, discharge summaries</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                          <span className="text-xl">💉</span>
                          <div>
                            <p className="font-medium">Vaccination Records</p>
                            <p className="text-sm text-gray-600">Immunization history and certificates</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {scannedText && (
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold flex items-center gap-2">
                        <CheckCircle className="h-5 w-5 text-green-600" />
                        Scanned Text (Editable)
                      </h3>
                      <Textarea
                        value={scannedText}
                        onChange={(e) => {
                          setScannedText(e.target.value)
                          setPrescriptionText(e.target.value)
                        }}
                        className="min-h-[200px] font-mono text-sm"
                        placeholder="Scanned text will appear here..."
                      />
                      <div className="flex gap-4">
                        <Button
                          onClick={() => {
                            setPrescriptionText(scannedText)
                            setCurrentSection("prescription")
                          }}
                          className="bg-teal-600 hover:bg-teal-700"
                        >
                          <Brain className="h-4 w-4 mr-2" />
                          Analyze with AI
                        </Button>
                        <Button
                          variant="outline"
                          onClick={() => {
                            setScannedText("")
                            setPrescriptionText("")
                          }}
                          className="bg-transparent"
                        >
                          Clear Text
                        </Button>
                      </div>
                    </div>
                  )}

                  <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
                    <h4 className="font-medium text-yellow-800 mb-2">📝 Tips for Better Scanning</h4>
                    <ul className="text-sm text-yellow-700 space-y-1">
                      <li>• Ensure good lighting and clear image quality</li>
                      <li>• Keep the document flat and avoid shadows</li>
                      <li>• Make sure all text is visible and not cut off</li>
                      <li>• For handwritten notes, ensure legible handwriting</li>
                      <li>• Review and edit the scanned text before analysis</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Results Section */}
          {currentSection === "results" && (
            <div className="space-y-6">
              <Card className="bg-white/90 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <span className="text-xl">📊</span>
                    AI Analysis Results
                  </CardTitle>
                  <CardDescription>Comprehensive AI-powered analysis of your prescription</CardDescription>
                </CardHeader>
                <CardContent>
                  {analysisResult?.analysis ? (
                    <div className="space-y-6">
                      <div className="flex items-center justify-between p-3 bg-teal-50 rounded-lg border border-teal-200">
                        <div className="flex items-center gap-2">
                          <Brain className="h-5 w-5 text-teal-600" />
                          <span className="font-medium text-teal-800">AI Analysis Complete</span>
                        </div>
                        <Badge variant="secondary" className="bg-teal-100 text-teal-800">
                          {analysisResult.analysis.analysisMethod}
                        </Badge>
                      </div>

                      {/* Extracted Drugs */}
                      <div>
                        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                          <Pill className="h-5 w-5" />
                          Extracted Medications ({analysisResult.analysis.extractedDrugs.length})
                        </h3>
                        <div className="grid gap-4">
                          {analysisResult.analysis.extractedDrugs.map((drug, index) => (
                            <Card key={index} className="border-l-4 border-l-teal-500 bg-white/90">
                              <CardContent className="p-4">
                                <div className="flex justify-between items-start mb-3">
                                  <div>
                                    <h4 className="font-semibold text-lg">{drug.name}</h4>
                                    <p className="text-sm text-gray-600">Generic: {drug.genericName}</p>
                                  </div>
                                  <Badge variant="outline" className="bg-teal-50 text-teal-700">
                                    {Math.round(drug.confidence * 100)}% confidence
                                  </Badge>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-3">
                                  <div>
                                    <p className="text-sm font-medium text-gray-700">Dosage</p>
                                    <p className="text-lg">{drug.dosage}</p>
                                  </div>
                                  <div>
                                    <p className="text-sm font-medium text-gray-700">Frequency</p>
                                    <p className="text-lg">{drug.frequency}</p>
                                  </div>
                                  <div>
                                    <p className="text-sm font-medium text-gray-700">Class</p>
                                    <p className="text-lg">{drug.therapeuticClass}</p>
                                  </div>
                                </div>

                                {drug.brandNames.length > 0 && (
                                  <div>
                                    <p className="text-sm font-medium text-gray-700 mb-1">Brand Names</p>
                                    <div className="flex flex-wrap gap-2">
                                      {drug.brandNames.map((brand, idx) => (
                                        <Badge key={idx} variant="secondary">
                                          {brand}
                                        </Badge>
                                      ))}
                                    </div>
                                  </div>
                                )}
                              </CardContent>
                            </Card>
                          ))}
                        </div>
                      </div>

                      {/* Drug Interactions */}
                      {analysisResult.analysis.interactions.length > 0 && (
                        <div>
                          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2 text-red-600">
                            <AlertTriangle className="h-5 w-5" />
                            Drug Interactions ({analysisResult.analysis.interactions.length})
                          </h3>
                          <div className="space-y-4">
                            {analysisResult.analysis.interactions.map((interaction, index) => (
                              <Alert key={index} variant="destructive">
                                <AlertTriangle className="h-4 w-4" />
                                <AlertDescription>
                                  <div className="space-y-2">
                                    <div className="font-semibold">
                                      {interaction.drug1} + {interaction.drug2}
                                      <Badge
                                        variant="destructive"
                                        className={`ml-2 ${
                                          interaction.severity === "high"
                                            ? "bg-red-600"
                                            : interaction.severity === "moderate"
                                              ? "bg-orange-600"
                                              : "bg-yellow-600"
                                        }`}
                                      >
                                        {interaction.severity.toUpperCase()} RISK
                                      </Badge>
                                    </div>
                                    <p>{interaction.description}</p>
                                    <div className="text-sm">
                                      <p>
                                        <strong>Mechanism:</strong> {interaction.mechanism}
                                      </p>
                                      <p>
                                        <strong>Clinical Effect:</strong> {interaction.clinicalEffect}
                                      </p>
                                    </div>
                                  </div>
                                </AlertDescription>
                              </Alert>
                            ))}
                          </div>
                        </div>
                      )}

                      <div className="flex gap-4 pt-6 border-t">
                        <Button
                          onClick={() => setCurrentSection("prescription")}
                          variant="outline"
                          className="flex-1 bg-transparent hover:bg-teal-50"
                        >
                          Analyze Another Prescription
                        </Button>
                        <Button
                          onClick={() => setCurrentSection("hospitals")}
                          className="flex-1 bg-teal-600 hover:bg-teal-700"
                        >
                          <HospitalIcon className="h-4 w-4 mr-2" />
                          Find Nearby Hospitals
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <Brain className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-900 mb-2">No Analysis Available</h3>
                      <p className="text-gray-500 mb-6">Analyze a prescription first to see detailed results here</p>
                      <Button
                        onClick={() => setCurrentSection("prescription")}
                        className="bg-teal-600 hover:bg-teal-700"
                      >
                        <Brain className="h-4 w-4 mr-2" />
                        Start AI Analysis
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          )}

          {/* Hospitals Section */}
          {currentSection === "hospitals" && (
            <div className="space-y-6">
              <Card className="bg-white/90 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <HospitalIcon className="h-5 w-5 text-teal-600" />
                    Nearby Hospitals & Medical Centers
                  </CardTitle>
                  <CardDescription>Find hospitals, clinics, and emergency centers near your location</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {userLocation && (
                    <div className="mb-4 p-3 bg-green-50 border border-green-200 rounded-lg">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                        <span className="text-sm font-medium text-green-800">
                          Location tracked: {userLocation.lat.toFixed(4)}, {userLocation.lng.toFixed(4)}
                        </span>
                      </div>
                    </div>
                  )}

                  <Button
                    onClick={findNearbyHospitals}
                    disabled={isLoadingLocation}
                    className="w-full bg-teal-600 hover:bg-teal-700"
                  >
                    {isLoadingLocation ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                        Getting Location...
                      </>
                    ) : (
                      <>
                        <MapPin className="h-4 w-4 mr-2" />
                        Find Nearby Hospitals
                      </>
                    )}
                  </Button>

                  {locationError && (
                    <Alert variant="destructive">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription>
                        {locationError}
                        <div className="mt-2">
                          <Button variant="outline" size="sm" onClick={findNearbyHospitals}>
                            Retry Location Access
                          </Button>
                        </div>
                      </AlertDescription>
                    </Alert>
                  )}

                  {nearbyHospitals.length > 0 && (
                    <div className="space-y-4">
                      <h3 className="font-semibold">Medical Facilities Near You:</h3>
                      {nearbyHospitals.map((hospital) => (
                        <Card key={hospital.id} className="bg-white/90 backdrop-blur-sm">
                          <CardContent className="p-4">
                            <div className="flex justify-between items-start mb-3">
                              <div className="space-y-2 flex-1">
                                <div className="flex items-center gap-2">
                                  <h4 className="font-semibold text-lg">{hospital.name}</h4>
                                  {hospital.emergencyServices && (
                                    <Badge variant="destructive" className="text-xs">
                                      Emergency
                                    </Badge>
                                  )}
                                  <Badge
                                    variant="outline"
                                    className={`text-xs ${
                                      hospital.type === "hospital"
                                        ? "bg-blue-50 text-blue-700"
                                        : hospital.type === "emergency"
                                          ? "bg-red-50 text-red-700"
                                          : "bg-green-50 text-green-700"
                                    }`}
                                  >
                                    {hospital.type.charAt(0).toUpperCase() + hospital.type.slice(1)}
                                  </Badge>
                                </div>
                                <p className="text-gray-600 flex items-center gap-1">
                                  <MapPin className="h-4 w-4" />
                                  {hospital.address}
                                </p>
                                <div className="flex items-center gap-4 text-sm">
                                  <span className="flex items-center gap-1">
                                    <Star className="h-4 w-4 text-yellow-500" />
                                    {hospital.rating.toFixed(1)}
                                  </span>
                                  <span className="text-teal-600 font-medium">{hospital.distance}</span>
                                  <span className="flex items-center gap-1 text-gray-600">
                                    <Phone className="h-4 w-4" />
                                    {hospital.phone}
                                  </span>
                                </div>
                                <div className="flex flex-wrap gap-2 mt-2">
                                  {hospital.specialties.map((specialty, index) => (
                                    <span
                                      key={index}
                                      className="px-2 py-1 bg-teal-100 text-teal-800 text-xs rounded-full"
                                    >
                                      {specialty}
                                    </span>
                                  ))}
                                </div>
                              </div>
                              <div className="flex flex-col gap-2 ml-4">
                                <Button variant="outline" size="sm" onClick={() => getDirections(hospital)}>
                                  <MapPin className="h-4 w-4 mr-1" />
                                  Directions
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => window.open(`tel:${hospital.phone}`)}
                                >
                                  <Phone className="h-4 w-4 mr-1" />
                                  Call
                                </Button>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          )}

          {/* Pharmacies Section */}
          {currentSection === "pharmacies" && (
            <div className="space-y-6">
              <Card className="bg-white/90 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <span className="text-xl">💊</span>
                    Nearby Pharmacies
                  </CardTitle>
                  <CardDescription>Find pharmacies and drugstores near your location</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {userLocation && (
                    <div className="mb-4 p-3 bg-green-50 border border-green-200 rounded-lg">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                        <span className="text-sm font-medium text-green-800">
                          Location tracked: {userLocation.lat.toFixed(4)}, {userLocation.lng.toFixed(4)}
                        </span>
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Button
                      onClick={findNearbyPharmacies}
                      disabled={isLoadingLocation}
                      className="bg-teal-600 hover:bg-teal-700"
                    >
                      {isLoadingLocation ? (
                        <>
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                          Finding Pharmacies...
                        </>
                      ) : (
                        <>
                          <MapPin className="h-4 w-4 mr-2" />
                          Find Nearby Pharmacies
                        </>
                      )}
                    </Button>

                    <Button onClick={findNearbyHospitals} variant="outline" className="bg-transparent hover:bg-teal-50">
                      <HospitalIcon className="h-4 w-4 mr-2" />
                      Find Hospitals Too
                    </Button>
                  </div>

                  {locationError && (
                    <Alert variant="destructive">
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription>
                        {locationError}
                        <div className="mt-2">
                          <Button variant="outline" size="sm" onClick={findNearbyPharmacies}>
                            Retry Location Access
                          </Button>
                        </div>
                      </AlertDescription>
                    </Alert>
                  )}

                  {nearbyPharmacies.length > 0 && (
                    <div className="space-y-4">
                      <h3 className="font-semibold">Pharmacies Near You:</h3>
                      {nearbyPharmacies.map((pharmacy) => (
                        <Card key={pharmacy.id} className="bg-white/90 backdrop-blur-sm">
                          <CardContent className="p-4">
                            <div className="flex justify-between items-start mb-3">
                              <div className="space-y-2 flex-1">
                                <div className="flex items-center gap-2">
                                  <h4 className="font-semibold text-lg">{pharmacy.name}</h4>
                                  {pharmacy.isOpen24Hours && (
                                    <Badge variant="secondary" className="text-xs bg-green-100 text-green-800">
                                      24 Hours
                                    </Badge>
                                  )}
                                  <Badge
                                    variant="outline"
                                    className={`text-xs ${
                                      pharmacy.type === "chain"
                                        ? "bg-blue-50 text-blue-700"
                                        : pharmacy.type === "independent"
                                          ? "bg-purple-50 text-purple-700"
                                          : "bg-green-50 text-green-700"
                                    }`}
                                  >
                                    {pharmacy.type.charAt(0).toUpperCase() + pharmacy.type.slice(1)}
                                  </Badge>
                                </div>
                                <p className="text-gray-600 flex items-center gap-1">
                                  <MapPin className="h-4 w-4" />
                                  {pharmacy.address}
                                </p>
                                <div className="flex items-center gap-4 text-sm">
                                  <span className="flex items-center gap-1">
                                    <Star className="h-4 w-4 text-yellow-500" />
                                    {pharmacy.rating.toFixed(1)}
                                  </span>
                                  <span className="text-teal-600 font-medium">{pharmacy.distance}</span>
                                  <span className="flex items-center gap-1 text-gray-600">
                                    <Phone className="h-4 w-4" />
                                    {pharmacy.phone}
                                  </span>
                                </div>
                                <div className="flex flex-wrap gap-2 mt-2">
                                  {pharmacy.services.map((service, index) => (
                                    <span
                                      key={index}
                                      className="px-2 py-1 bg-teal-100 text-teal-800 text-xs rounded-full"
                                    >
                                      {service}
                                    </span>
                                  ))}
                                </div>
                              </div>
                              <div className="flex flex-col gap-2 ml-4">
                                <Button variant="outline" size="sm" onClick={() => getDirections(pharmacy)}>
                                  <MapPin className="h-4 w-4 mr-1" />
                                  Directions
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => window.open(`tel:${pharmacy.phone}`)}
                                >
                                  <Phone className="h-4 w-4 mr-1" />
                                  Call
                                </Button>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}

                  {nearbyPharmacies.length === 0 && !isLoadingLocation && !locationError && (
                    <div className="text-center py-8">
                      <span className="text-4xl mb-4 block">💊</span>
                      <h3 className="text-lg font-medium text-gray-900 mb-2">No Pharmacies Found Yet</h3>
                      <p className="text-gray-500 mb-4">
                        Click "Find Nearby Pharmacies" to locate pharmacies in your area
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          )}

          {/* About Section */}
          {currentSection === "about" && (
            <div className="space-y-0">
              {/* Hero Section with Green Background */}
              <div className="bg-gradient-to-r from-emerald-500 to-teal-600 text-white p-8 rounded-t-lg relative overflow-hidden">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
                  <div className="space-y-6">
                    <h1 className="text-4xl font-bold">Meet AI Medical Assistant</h1>
                    <p className="text-lg leading-relaxed opacity-90">
                      Our AI-powered health assistant helps you understand your prescriptions, analyze medical reports,
                      and gain insights into your health condition with advanced machine learning and medical expertise.
                    </p>

                    {/* Feature Highlights */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8">
                      <div className="flex items-center gap-3 bg-white/10 backdrop-blur-sm rounded-lg p-3">
                        <Clock className="h-6 w-6 text-white" />
                        <div>
                          <h3 className="font-semibold text-sm">24/7 AI Analysis</h3>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 bg-white/10 backdrop-blur-sm rounded-lg p-3">
                        <UserCheck className="h-6 w-6 text-white" />
                        <div>
                          <h3 className="font-semibold text-sm">Medical Expertise</h3>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 bg-white/10 backdrop-blur-sm rounded-lg p-3">
                        <CheckCircle className="h-6 w-6 text-white" />
                        <div>
                          <h3 className="font-semibold text-sm">Secure & Private</h3>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Doctor Illustration */}
                  <div className="flex justify-center lg:justify-end">
                    <div className="relative">
                      <img
                        src="/professional-doctor.png"
                        alt="AI Medical Assistant Doctor"
                        className="w-60 h-75 object-cover rounded-lg shadow-lg"
                      />
                      <div className="absolute -top-4 -right-4 w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
                        <Brain className="h-8 w-8 text-white" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Mission and Vision Section */}
              <div className="bg-white p-8">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* Our Mission */}
                  <div className="space-y-4">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                        <Info className="h-6 w-6 text-blue-600" />
                      </div>
                      <h2 className="text-2xl font-bold text-gray-800">Our Mission</h2>
                    </div>
                    <p className="text-gray-600 leading-relaxed">
                      At AI Medical Assistant, our mission is to ensure everyone has easy access to understandable and
                      accurate health information. By eliminating geographical, economic, and time constraints, our AI
                      doctor helps everyone understand their health condition and make informed medical decisions.
                    </p>
                  </div>

                  {/* Our Vision */}
                  <div className="space-y-4">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                        <Brain className="h-6 w-6 text-purple-600" />
                      </div>
                      <h2 className="text-2xl font-bold text-gray-800">Our Vision</h2>
                    </div>
                    <p className="text-gray-600 leading-relaxed">
                      Our vision is to democratize healthcare services by combining artificial intelligence and medical
                      science, making them accessible to everyone. In the future, we aim to be the first point of
                      contact for health concerns, helping people make more informed health decisions.
                    </p>
                  </div>
                </div>
              </div>

              {/* Key Features Section */}
              <div className="bg-gray-50 p-8 rounded-b-lg">
                <h2 className="text-3xl font-bold text-center text-gray-800 mb-12">Key Features</h2>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  {/* Prescription Analysis */}
                  <div className="text-center space-y-4">
                    <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto">
                      <Pill className="h-8 w-8 text-emerald-600" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-800">Prescription Analysis</h3>
                    <p className="text-gray-600 leading-relaxed">
                      AI-powered analysis of prescriptions with drug interaction detection and dosage recommendations.
                    </p>
                  </div>

                  {/* Medical Report Analysis */}
                  <div className="text-center space-y-4">
                    <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
                      <svg className="h-8 w-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
                        />
                      </svg>
                    </div>
                    <h3 className="text-xl font-bold text-gray-800">Medical Report Analysis</h3>
                    <p className="text-gray-600 leading-relaxed">
                      Upload and analyze medical reports to get simple explanations and treatment recommendations.
                    </p>
                  </div>

                  {/* Health Profile Analysis */}
                  <div className="text-center space-y-4">
                    <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto">
                      <UserCheck className="h-8 w-8 text-purple-600" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-800">Health Profile Analysis</h3>
                    <p className="text-gray-600 leading-relaxed">
                      Comprehensive health profiling with BMI calculation, vital signs tracking, and lifestyle
                      assessment.
                    </p>
                  </div>
                </div>

                {/* Additional Features */}
                <div className="mt-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <div className="flex items-center gap-3 bg-white p-4 rounded-lg shadow-sm">
                    <CheckCircle className="h-6 w-6 text-green-600" />
                    <div>
                      <h4 className="font-semibold text-gray-800">99.2% Accuracy</h4>
                      <p className="text-sm text-gray-600">Industry-leading precision</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 bg-white p-4 rounded-lg shadow-sm">
                    <CheckCircle className="h-6 w-6 text-green-600" />
                    <div>
                      <h4 className="font-semibold text-gray-800">HIPAA Compliant</h4>
                      <p className="text-sm text-gray-600">Enterprise-grade security</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 bg-white p-4 rounded-lg shadow-sm">
                    <CheckCircle className="h-6 w-6 text-green-600" />
                    <div>
                      <h4 className="font-semibold text-gray-800">24/7 Available</h4>
                      <p className="text-sm text-gray-600">Round-the-clock support</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 bg-white p-4 rounded-lg shadow-sm">
                    <CheckCircle className="h-6 w-6 text-green-600" />
                    <div>
                      <h4 className="font-semibold text-gray-800">AI-Powered</h4>
                      <p className="text-sm text-gray-600">Advanced machine learning</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* FAQ Section */}
          {currentSection === "faq" && (
            <div className="space-y-6">
              <Card className="bg-white/90 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <HelpCircle className="h-5 w-5 text-teal-600" />
                    Frequently Asked Questions
                  </CardTitle>
                  <CardDescription>Get answers to common questions about DoctorAI</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="border-b border-gray-200 pb-4">
                      <h4 className="font-semibold text-gray-800 mb-2">How accurate is the AI analysis?</h4>
                      <p className="text-gray-600 text-sm">
                        Our AI-powered analysis achieves 99.2% accuracy in drug identification and interaction
                        detection, validated through extensive clinical testing and real-world deployment across
                        healthcare facilities.
                      </p>
                    </div>

                    <div className="border-b border-gray-200 pb-4">
                      <h4 className="font-semibold text-gray-800 mb-2">Is my patient data secure?</h4>
                      <p className="text-gray-600 text-sm">
                        Yes, we maintain the highest security standards with HIPAA compliance, end-to-end encryption,
                        and secure data processing. Patient information is never stored permanently on our servers and
                        all data is processed in secure, encrypted environments.
                      </p>
                    </div>

                    <div className="border-b border-gray-200 pb-4">
                      <h4 className="font-semibold text-gray-800 mb-2">What types of prescriptions can be analyzed?</h4>
                      <p className="text-gray-600 text-sm">
                        Our AI can analyze all standard prescription formats including handwritten notes, typed
                        prescriptions, and electronic health records. It supports over 10,000 medications and their
                        interactions, covering all major therapeutic classes.
                      </p>
                    </div>

                    <div className="border-b border-gray-200 pb-4">
                      <h4 className="font-semibold text-gray-800 mb-2">How do I get started?</h4>
                      <p className="text-gray-600 text-sm">
                        Simply create an account with your medical credentials, verify your license, and start analyzing
                        prescriptions immediately. Our platform is designed for healthcare professionals and requires
                        proper medical authorization for access.
                      </p>
                    </div>

                    <div className="border-b border-gray-200 pb-4">
                      <h4 className="font-semibold text-gray-800 mb-2">
                        What makes DoctorAI different from other platforms?
                      </h4>
                      <p className="text-gray-600 text-sm">
                        DoctorAI uses advanced machine learning models specifically trained on medical and healthcare
                        data, providing superior accuracy compared to general-purpose AI models. We understand medical
                        terminology, drug interactions, and clinical contexts with unprecedented precision.
                      </p>
                    </div>

                    <div className="border-b border-gray-200 pb-4">
                      <h4 className="font-semibold text-gray-800 mb-2">
                        Can I integrate DoctorAI with my existing systems?
                      </h4>
                      <p className="text-gray-600 text-sm">
                        Yes, DoctorAI offers seamless integration with most Electronic Health Record (EHR) systems,
                        Hospital Information Systems (HIS), and pharmacy management systems through our comprehensive
                        API and integration tools.
                      </p>
                    </div>

                    <div className="border-b border-gray-200 pb-4">
                      <h4 className="font-semibold text-gray-800 mb-2">What kind of support do you provide?</h4>
                      <p className="text-gray-600 text-sm">
                        We provide comprehensive 24/7 technical support, extensive training programs for healthcare
                        staff, detailed documentation, and ongoing consultation services. Our support team includes
                        medical professionals and technical experts.
                      </p>
                    </div>

                    <div className="border-b border-gray-200 pb-4">
                      <h4 className="font-semibold text-gray-800 mb-2">How much does DoctorAI cost?</h4>
                      <p className="text-gray-600 text-sm">
                        We offer flexible pricing plans based on the size of your healthcare facility and usage
                        requirements. Our plans include per-user licensing, enterprise solutions, and custom packages
                        for large healthcare systems. Contact our sales team for a personalized quote.
                      </p>
                    </div>

                    <div className="border-b border-gray-200 pb-4">
                      <h4 className="font-semibold text-gray-800 mb-2">Is there a free trial available?</h4>
                      <p className="text-gray-600 text-sm">
                        Yes, we offer a 30-day free trial for qualified healthcare professionals and institutions. The
                        trial includes full access to all features, comprehensive support, and training resources to
                        help you evaluate the platform.
                      </p>
                    </div>

                    <div>
                      <h4 className="font-semibold text-gray-800 mb-2">How often is the drug database updated?</h4>
                      <p className="text-gray-600 text-sm">
                        Our drug database is updated continuously with the latest FDA approvals, drug interactions, and
                        clinical research. We maintain partnerships with major pharmaceutical databases and medical
                        institutions to ensure our information is always current and accurate.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white/90 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle>Still have questions?</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center space-y-4">
                    <p className="text-gray-600">
                      Can't find the answer you're looking for? Our support team is here to help.
                    </p>
                    <div className="flex flex-col sm:flex-row gap-4 justify-center">
                      <Button className="bg-teal-600 hover:bg-teal-700">
                        <Mail className="h-4 w-4 mr-2" />
                        Contact Support
                      </Button>
                      <Button variant="outline" className="bg-transparent">
                        <Phone className="h-4 w-4 mr-2" />
                        Schedule a Call
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default function Home() {
  const [currentView, setCurrentView] = useState<"landing" | "login" | "dashboard">("landing")
  const [username, setUsername] = useState("")

  const handleGetStarted = () => {
    setCurrentView("login")
  }

  const handleLogin = (user: string) => {
    setUsername(user)
    setCurrentView("dashboard")
  }

  const handleLogout = () => {
    setCurrentView("landing")
    setUsername("")
  }

  if (currentView === "landing") {
    return <LandingPage onGetStarted={handleGetStarted} />
  }

  if (currentView === "login") {
    return <LoginForm onLogin={handleLogin} />
  }

  return <DashboardApp username={username} onLogout={handleLogout} />
}
