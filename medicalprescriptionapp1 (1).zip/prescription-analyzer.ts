// Utility functions for prescription analysis

export interface DrugInfo {
  name: string
  dosage: string
  frequency: string
  confidence: number
  genericName: string
  brandNames: string[]
  therapeuticClass: string
}

export interface DrugInteraction {
  drug1: string
  drug2: string
  severity: "high" | "moderate" | "low"
  description: string
  mechanism: string
  clinicalEffect: string
}

export interface DosageRecommendation {
  drug: string
  recommendedDosage: string
  reason: string
  ageSpecific: boolean
  weightBased: boolean
  currentDosage?: string
}

export interface AlternativeMedication {
  originalDrug: string
  alternative: string
  reason: string
  benefits: string[]
  considerations: string[]
  therapeuticEquivalence: number
}

// Drug database with therapeutic information
export const DRUG_DATABASE: Record<
  string,
  {
    genericName: string
    brandNames: string[]
    therapeuticClass: string
    commonDosages: string[]
    maxDailyDose: string
    contraindications: string[]
    sideEffects: string[]
  }
> = {
  lisinopril: {
    genericName: "Lisinopril",
    brandNames: ["Prinivil", "Zestril"],
    therapeuticClass: "ACE Inhibitor",
    commonDosages: ["2.5mg", "5mg", "10mg", "20mg", "40mg"],
    maxDailyDose: "40mg",
    contraindications: ["Pregnancy", "Angioedema history", "Bilateral renal artery stenosis"],
    sideEffects: ["Dry cough", "Hyperkalemia", "Hypotension", "Angioedema"],
  },
  metformin: {
    genericName: "Metformin",
    brandNames: ["Glucophage", "Fortamet", "Glumetza"],
    therapeuticClass: "Biguanide",
    commonDosages: ["500mg", "850mg", "1000mg"],
    maxDailyDose: "2550mg",
    contraindications: ["Severe kidney disease", "Metabolic acidosis", "Diabetic ketoacidosis"],
    sideEffects: ["Nausea", "Diarrhea", "Lactic acidosis (rare)", "Vitamin B12 deficiency"],
  },
  atorvastatin: {
    genericName: "Atorvastatin",
    brandNames: ["Lipitor"],
    therapeuticClass: "HMG-CoA Reductase Inhibitor",
    commonDosages: ["10mg", "20mg", "40mg", "80mg"],
    maxDailyDose: "80mg",
    contraindications: ["Active liver disease", "Pregnancy", "Breastfeeding"],
    sideEffects: ["Muscle pain", "Liver enzyme elevation", "Rhabdomyolysis (rare)"],
  },
  warfarin: {
    genericName: "Warfarin",
    brandNames: ["Coumadin", "Jantoven"],
    therapeuticClass: "Anticoagulant",
    commonDosages: ["1mg", "2mg", "2.5mg", "3mg", "4mg", "5mg", "6mg", "7.5mg", "10mg"],
    maxDailyDose: "Variable (INR-dependent)",
    contraindications: ["Active bleeding", "Pregnancy", "Severe hypertension"],
    sideEffects: ["Bleeding", "Bruising", "Hair loss", "Skin necrosis (rare)"],
  },
}

// Known drug interactions database
export const DRUG_INTERACTIONS: DrugInteraction[] = [
  {
    drug1: "Warfarin",
    drug2: "Aspirin",
    severity: "high",
    description: "Increased risk of bleeding due to additive anticoagulant effects",
    mechanism: "Additive anticoagulant and antiplatelet effects",
    clinicalEffect: "Significantly increased bleeding risk",
  },
  {
    drug1: "Lisinopril",
    drug2: "Metformin",
    severity: "low",
    description: "ACE inhibitors may enhance the hypoglycemic effect of metformin",
    mechanism: "Enhanced insulin sensitivity",
    clinicalEffect: "Potential for enhanced glucose lowering",
  },
  {
    drug1: "Atorvastatin",
    drug2: "Warfarin",
    severity: "moderate",
    description: "Statins may potentiate the anticoagulant effect of warfarin",
    mechanism: "CYP enzyme inhibition affecting warfarin metabolism",
    clinicalEffect: "Increased INR and bleeding risk",
  },
  {
    drug1: "Metformin",
    drug2: "Furosemide",
    severity: "moderate",
    description: "Loop diuretics may increase metformin levels and lactic acidosis risk",
    mechanism: "Reduced renal clearance of metformin",
    clinicalEffect: "Increased risk of lactic acidosis",
  },
]

interface GraniteModelResponse {
  extracted_drugs: Array<{
    name: string
    dosage: string
    frequency: string
    confidence: number
    generic_name: string
    therapeutic_class: string
  }>
  medical_entities: Array<{
    entity: string
    type: string
    confidence: number
  }>
  clinical_insights: {
    risk_factors: string[]
    recommendations: string[]
    contraindications: string[]
  }
}

// Enhanced drug extraction using IBM Granite models
export async function extractDrugsWithGranite(prescriptionText: string): Promise<DrugInfo[]> {
  try {
    // Call IBM Granite model via Hugging Face API
    const response = await fetch("https://api-inference.huggingface.co/models/ibm-granite/granite-3b-code-instruct", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.HUGGINGFACE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        inputs: `Extract drug information from this medical prescription text. Return structured data with drug names, dosages, frequencies, and confidence scores:

${prescriptionText}

Format the response as JSON with the following structure:
{
  "extracted_drugs": [
    {
      "name": "drug_name",
      "dosage": "dosage_amount",
      "frequency": "frequency_schedule",
      "confidence": 0.95,
      "generic_name": "generic_name",
      "therapeutic_class": "drug_class"
    }
  ]
}`,
        parameters: {
          max_new_tokens: 500,
          temperature: 0.1,
          return_full_text: false,
        },
      }),
    })

    if (!response.ok) {
      console.warn("Granite model API failed, falling back to pattern matching")
      return extractDrugsWithPatterns(prescriptionText)
    }

    const result = await response.json()
    const graniteResponse: GraniteModelResponse = JSON.parse(result[0]?.generated_text || '{"extracted_drugs": []}')

    // Convert Granite response to DrugInfo format
    const drugs: DrugInfo[] = graniteResponse.extracted_drugs.map((drug) => ({
      name: drug.name,
      dosage: drug.dosage,
      frequency: drug.frequency,
      confidence: drug.confidence,
      genericName: drug.generic_name || drug.name,
      brandNames: getBrandNames(drug.name),
      therapeuticClass: drug.therapeutic_class || getTherapeuticClass(drug.name),
    }))

    return drugs.length > 0 ? drugs : extractDrugsWithPatterns(prescriptionText)
  } catch (error) {
    console.error("Error with Granite model:", error)
    return extractDrugsWithPatterns(prescriptionText)
  }
}

// Fallback pattern-based extraction (existing logic)
function extractDrugsWithPatterns(prescriptionText: string): DrugInfo[] {
  const drugs: DrugInfo[] = []
  const lines = prescriptionText.toLowerCase().split("\n")

  // Enhanced pattern matching for drug extraction
  const drugPatterns = [
    /(\w+)\s+(\d+(?:\.\d+)?)\s*(mg|g|ml|mcg|units?)\s+(.+)/i,
    /(\w+)\s+(\d+(?:\.\d+)?)\s*(mg|g|ml|mcg|units?)/i,
    /take\s+(\w+)\s+(\d+(?:\.\d+)?)\s*(mg|g|ml|mcg|units?)/i,
  ]

  lines.forEach((line) => {
    drugPatterns.forEach((pattern) => {
      const match = line.match(pattern)
      if (match) {
        const [, name, dose, unit, frequency] = match
        const drugName = name.charAt(0).toUpperCase() + name.slice(1)

        if (DRUG_DATABASE[name.toLowerCase()]) {
          drugs.push({
            name: drugName,
            dosage: `${dose}${unit}`,
            frequency: frequency || "as directed",
            confidence: 0.8,
            genericName: DRUG_DATABASE[name.toLowerCase()].genericName,
            brandNames: DRUG_DATABASE[name.toLowerCase()].brandNames,
            therapeuticClass: DRUG_DATABASE[name.toLowerCase()].therapeuticClass,
          })
        }
      }
    })
  })

  return drugs
}

// Helper functions for drug information
function getBrandNames(drugName: string): string[] {
  const drugInfo = DRUG_DATABASE[drugName.toLowerCase()]
  return drugInfo?.brandNames || []
}

function getTherapeuticClass(drugName: string): string {
  const drugInfo = DRUG_DATABASE[drugName.toLowerCase()]
  return drugInfo?.therapeuticClass || "Unknown"
}

export async function findDrugInteractionsWithGranite(drugs: string[]): Promise<DrugInteraction[]> {
  try {
    const response = await fetch("https://api-inference.huggingface.co/models/ibm-granite/granite-3b-code-instruct", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.HUGGINGFACE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        inputs: `Analyze potential drug interactions for these medications: ${drugs.join(", ")}. 
        
Provide detailed interaction analysis including severity levels, mechanisms, and clinical effects. Format as JSON:
{
  "interactions": [
    {
      "drug1": "drug_name_1",
      "drug2": "drug_name_2", 
      "severity": "high|moderate|low",
      "description": "interaction_description",
      "mechanism": "interaction_mechanism",
      "clinical_effect": "clinical_impact"
    }
  ]
}`,
        parameters: {
          max_new_tokens: 800,
          temperature: 0.1,
          return_full_text: false,
        },
      }),
    })

    if (response.ok) {
      const result = await response.json()
      const graniteResponse = JSON.parse(result[0]?.generated_text || '{"interactions": []}')

      if (graniteResponse.interactions && graniteResponse.interactions.length > 0) {
        return graniteResponse.interactions
      }
    }
  } catch (error) {
    console.error("Error with Granite interaction analysis:", error)
  }

  // Fallback to existing interaction detection
  return findDrugInteractions(drugs)
}

export function findDrugInteractions(drugs: string[]): DrugInteraction[] {
  const interactions: DrugInteraction[] = []

  for (let i = 0; i < drugs.length; i++) {
    for (let j = i + 1; j < drugs.length; j++) {
      const drug1 = drugs[i].toLowerCase()
      const drug2 = drugs[j].toLowerCase()

      const interaction = DRUG_INTERACTIONS.find(
        (int) =>
          (int.drug1.toLowerCase() === drug1 && int.drug2.toLowerCase() === drug2) ||
          (int.drug1.toLowerCase() === drug2 && int.drug2.toLowerCase() === drug1),
      )

      if (interaction) {
        interactions.push(interaction)
      }
    }
  }

  return interactions.sort((a, b) => {
    const severityOrder = { high: 3, moderate: 2, low: 1 }
    return severityOrder[b.severity] - severityOrder[a.severity]
  })
}

export function generateDosageRecommendations(
  drugs: DrugInfo[],
  patientAge?: number,
  patientWeight?: number,
): DosageRecommendation[] {
  const recommendations: DosageRecommendation[] = []

  drugs.forEach((drug) => {
    const drugInfo = DRUG_DATABASE[drug.name.toLowerCase()]
    if (!drugInfo) return

    let recommendation: DosageRecommendation | null = null

    // Age-based recommendations
    if (patientAge && patientAge >= 65) {
      if (drug.name.toLowerCase() === "lisinopril") {
        recommendation = {
          drug: drug.name,
          recommendedDosage: "2.5mg once daily",
          reason: "Lower starting dose recommended for elderly patients to reduce hypotension risk",
          ageSpecific: true,
          weightBased: false,
          currentDosage: drug.dosage,
        }
      } else if (drug.name.toLowerCase() === "metformin") {
        recommendation = {
          drug: drug.name,
          recommendedDosage: "500mg once daily initially",
          reason: "Start with lower dose in elderly patients and monitor renal function",
          ageSpecific: true,
          weightBased: false,
          currentDosage: drug.dosage,
        }
      }
    }

    // Weight-based recommendations
    if (patientWeight && patientWeight < 50) {
      if (drug.name.toLowerCase() === "warfarin") {
        recommendation = {
          drug: drug.name,
          recommendedDosage: "2mg daily initially",
          reason: "Lower starting dose recommended for patients with low body weight",
          ageSpecific: false,
          weightBased: true,
          currentDosage: drug.dosage,
        }
      }
    }

    if (recommendation) {
      recommendations.push(recommendation)
    }
  })

  return recommendations
}

export function generateAlternatives(drugs: DrugInfo[]): AlternativeMedication[] {
  const alternatives: AlternativeMedication[] = []

  drugs.forEach((drug) => {
    let alternative: AlternativeMedication | null = null

    switch (drug.name.toLowerCase()) {
      case "atorvastatin":
        alternative = {
          originalDrug: drug.name,
          alternative: "Rosuvastatin",
          reason: "More potent LDL reduction with potentially fewer drug interactions",
          benefits: [
            "Higher potency at lower doses",
            "Less affected by CYP3A4 interactions",
            "Better efficacy in certain patient populations",
          ],
          considerations: ["May be more expensive", "Different dosing schedule may be needed"],
          therapeuticEquivalence: 0.9,
        }
        break

      case "lisinopril":
        alternative = {
          originalDrug: drug.name,
          alternative: "Losartan",
          reason: "ARB alternative with lower incidence of dry cough",
          benefits: [
            "No dry cough side effect",
            "Similar cardiovascular protection",
            "Better tolerated in some patients",
          ],
          considerations: ["May be more expensive", "Different mechanism of action"],
          therapeuticEquivalence: 0.85,
        }
        break

      case "metformin":
        alternative = {
          originalDrug: drug.name,
          alternative: "Empagliflozin",
          reason: "SGLT2 inhibitor with additional cardiovascular benefits",
          benefits: ["Cardiovascular risk reduction", "Weight loss benefit", "Lower hypoglycemia risk"],
          considerations: ["Higher cost", "Risk of genital infections", "Requires adequate kidney function"],
          therapeuticEquivalence: 0.8,
        }
        break
    }

    if (alternative) {
      alternatives.push(alternative)
    }
  })

  return alternatives
}
